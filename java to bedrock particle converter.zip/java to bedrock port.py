import os
import re
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox

def fix_particle_line(line, old_particle=None, new_particle=None, scale=1.0):
    """
    1. Swaps particle names if requested.
    2. Ensures 'minecraft:' namespace.
    3. Multiplies coordinates by 'scale'.
    4. Trims Java-specific arguments.
    """
    if "particle " in line:
        # Particle Name Swap
        if old_particle and new_particle:
            line = line.replace(f"minecraft:{old_particle}", new_particle)
            line = line.replace(f" {old_particle} ", f" {new_particle} ")

        parts = line.split()
        try:
            idx = parts.index("particle")
            if len(parts) > idx + 1:
                p_name = parts[idx + 1]
                if ":" not in p_name:
                    parts[idx + 1] = f"minecraft:{p_name}"
            
            # Coordinate Scaling
            if scale != 1.0:
                for i in range(idx + 2, idx + 5):
                    if i < len(parts) and parts[i].startswith('~'):
                        num = float(parts[i][1:]) if len(parts[i]) > 1 else 0.0
                        parts[i] = f"~{round(num * scale, 4)}"

            # Return Bedrock Syntax (Name + X Y Z)
            return " ".join(parts[:idx + 5]) + "\n"
        except (ValueError, IndexError):
            pass
    return line

def get_file_content(base_path, func_path, p_word, old_p, new_p, scale, iterations):
    """Reads and processes sub-files (frames/l0) for merging."""
    clean_rel_path = func_path.strip().lstrip('/')
    full_path = os.path.join(base_path, f"{clean_rel_path}.mcfunction")
    
    if os.path.exists(full_path):
        with open(full_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            processed = []
            for l in lines:
                if not l.strip(): continue 
                l = l.replace("cw_particleplot", p_word)
                l = re.sub(r"[\w\d_-]+:", "", l)
                fixed_l = fix_particle_line(l, old_p, new_p, scale)
                # Duplicate for density
                for _ in range(iterations):
                    processed.append(fixed_l)
            return processed, full_path
    return None, None

def main_converter():
    root = tk.Tk()
    root.withdraw()
    folder_path = filedialog.askdirectory(title="Select the Root Project Folder")
    if not folder_path: return

    # User Inputs
    new_animate = input("New name for 'animate.mcfunction': ")
    new_logic = input("New name for 'l1_0.mcfunction': ")
    p_word = input("Word to replace 'cw_particleplot': ")
    
    print("\n--- Optional Particle Scaling ---")
    scale_input = input("Enter scale multiplier (e.g. 5) or press Enter to skip: ").strip()
    scale = float(scale_input) if scale_input else 1.0
    
    gap_input = input("Enter density (iterations) or press Enter for Auto-Fill: ").strip()
    iterations = int(gap_input) if gap_input else int(max(1, scale))

    print("\n--- Optional Particle Swapper ---")
    old_p = input("Particle to change FROM (or Enter to skip): ").strip()
    new_p = input("Particle to change TO: ").strip()
    if new_p and ":" not in new_p: new_p = f"minecraft:{new_p}"

    files_to_delete = set()
    animate_old, logic_old = "", ""

    # Pass 1: Process and Merge
    for root_dir, dirs, files in os.walk(folder_path):
        for filename in files:
            if not filename.endswith(".mcfunction"): continue
            file_path = os.path.join(root_dir, filename)
            
            if filename == "animate.mcfunction": animate_old = file_path
            if filename == "l1_0.mcfunction": logic_old = file_path

            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            new_lines = []
            for line in lines:
                if not line.strip(): continue
                line = line.replace("cw_particleplot", p_word)
                line = re.sub(r"[\w\d_-]+:", "", line)
                line = line.replace("animate", new_animate).replace("demo/l1/l1_0", new_logic)

                # Flattening Logic
                match = re.search(r"(execute\s+if\s+score\s+.*?\s+matches\s+\S+)\s+run\s+function\s+([\w\d/_.-]+)", line)
                if match:
                    parent_cond = match.group(1)
                    sub_path = match.group(2)
                    if "demo/l0" in sub_path or "demo/frames" in sub_path:
                        child_lines, child_full = get_file_content(folder_path, sub_path, p_word, old_p, new_p, scale, iterations)
                        if child_lines:
                            for c_line in child_lines:
                                new_lines.append(f"{parent_cond} run {c_line.strip()}\n")
                            files_to_delete.add(child_full)
                            continue 

                fixed_line = fix_particle_line(line, old_p, new_p, scale)
                for _ in range(iterations if "particle " in line else 1):
                    new_lines.append(fixed_line)

            with open(file_path, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)

    # Pass 2: Move and Cleanup
    if animate_old: shutil.move(animate_old, os.path.join(folder_path, f"{new_animate}.mcfunction"))
    if logic_old: shutil.move(logic_old, os.path.join(folder_path, f"{new_logic}.mcfunction"))
    for f in files_to_delete: 
        if os.path.exists(f): os.remove(f)
    
    demo_dir = os.path.join(folder_path, "demo")
    if os.path.exists(demo_dir): shutil.rmtree(demo_dir)

    messagebox.showinfo("Success", "All files merged, scaled, and cleaned!")

if __name__ == "__main__":
    main_converter()