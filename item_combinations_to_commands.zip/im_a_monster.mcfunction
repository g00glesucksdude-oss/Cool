#defines in which state nautilus shells in
tag @a[hasitem={item=nautilus_shell,location=slot.weapon.mainhand}] add isholdshell
tag @a[tag=isholdshell] add hasheldshell
tag @a[hasitem={item=nautilus_shell,location=slot.weapon.mainhand,quantity=0}] remove isholdshell
#defines if holding explode beam //isholdcl means is holding explode beam//
tag @a[tag=hasheldshell,hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand,quantity=0}] remove isholdcl
execute as @a[tag=hasheldshell] at @s[hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand}] run tp @s ~~~
execute as @a[tag=hasheldcl] at @s[hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand,quantity=0}] unless entity @s[tag=isholdcl] run tag @s remove hasheldshell

#it is easy to get lost in this mess so DONT GET LOST (this is so unreasoanbly complicated its practically black magic)
#defines in which state explode beam is in
tag @a[hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand}] add isholdcl
tag @a[tag=isholdcl] add hasheldcl
tag @a[hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand,quantity=0}] remove isholdcl
tag @a[tag=!hasheldshell] remove hasheldcl
-----------------------------------------------------------------------------------------------------------------------------------------

#advanced version clean up /this was inspired by this formula/
tag @a[hasitem={item=nautilus_shell,location=slot.weapon.mainhand}] add isholdshell
tag @a[tag=isholdshell] add hasheldshell
tag @a[hasitem={item=nautilus_shell,location=slot.weapon.mainhand,quantity=0}] remove isholdshell
tag @a[tag=hasheldshell,hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand,quantity=0}] remove isholdcl
execute as @a[tag=hasheldshell] at @s[hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand}] run tp @s ~ ~ ~
execute as @a[tag=hasheldcl] at @s[hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand,quantity=0}] unless entity @s[tag=isholdcl] run tag @s remove hasheldshell
tag @a[hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand}] add isholdcl
tag @a[tag=isholdcl] add hasheldcl
tag @a[hasitem={item=godofexplosion:explode_beam,location=slot.weapon.mainhand,quantity=0}] remove isholdcl
tag @a[tag=!hasheldshell] remove hasheldcl


#this is one of the most inefficient methods of doing this but it is my favorite way since its gate keeping how to do it
#its like WHAT THE FREAK EVEN IS THIS