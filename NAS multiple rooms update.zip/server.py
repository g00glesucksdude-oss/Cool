import os
import shutil
import socket
import logging
from fastapi import FastAPI, UploadFile, File, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles

logging.getLogger("uvicorn.access").setLevel(logging.WARNING)

app = FastAPI()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "archive_rooms")

# --- MULTI-DRIVE CONFIGURATION ---
# Add as many paths as you want here. 
# Use 'r' before the quotes to avoid path errors with brackets/spaces.
DRIVES = [
    "C:/Users/g00gl/Downloads/[Judas] Kawaii Dake ja Nai Shikimori-san (Shikimori's Not Just a Cutie) (Season 1) [1080p][HEVC x265 10bit][Multi-Subs]",
    "C:/Users/g00gl/Downloads"
]
# ---------------------------------

os.makedirs(DATA_DIR, exist_ok=True)

# Mount each drive under a unique mount point (drive0, drive1, etc.)
for i, path in enumerate(DRIVES):
    if os.path.exists(path):
        app.mount(f"/drive{i}", StaticFiles(directory=path), name=f"drive{i}")

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 1))
        ip = s.getsockname()[0]
    except Exception: ip = '127.0.0.1'
    finally: s.close()
    return ip

@app.get("/streams")
async def view_streams():
    html = "<h1>🎬 Multi-Drive Vault</h1>"
    found_any = False

    for i, path in enumerate(DRIVES):
        if not os.path.exists(path):
            html += f"<fieldset style='color:red'><legend>Drive {i}</legend>Disconnected: {path}</fieldset><br>"
            continue
        
        found_any = True
        drive_name = os.path.basename(path)
        html += f"<fieldset><legend>📂 {drive_name}</legend><ul>"
        
        for root, _, filenames in os.walk(path):
            for f in filenames:
                # Calculate the link relative to the mount point
                rel_path = os.path.relpath(os.path.join(root, f), path).replace("\\", "/")
                html += f'<li><a href="/drive{i}/{rel_path}" target="_blank">{f}</a></li>'
        
        html += "</ul></fieldset><br>"

    if not found_any:
        html += "<p>No drives are currently connected.</p>"
    
    html += "<a href='/'>Back to Archive</a>"
    return HTMLResponse(html)

# --- ARCHIVE LOGIC (Same as before) ---

@app.post("/upload")
async def upload(room: str, file: UploadFile = File(...)):
    path = os.path.join(DATA_DIR, room)
    os.makedirs(path, exist_ok=True)
    with open(os.path.join(path, file.filename), "wb") as b: shutil.copyfileobj(file.file, b)
    await notify_room(room)
    return {"status": "ok"}

@app.get("/list")
async def list_files(room: str):
    p = os.path.join(DATA_DIR, room)
    return {"files": os.listdir(p) if os.path.exists(p) else []}

@app.delete("/delete/{room}/{name}")
async def delete_file(room: str, name: str):
    p = os.path.join(DATA_DIR, room, name)
    if os.path.exists(p): os.remove(p)
    await notify_room(room)
    return {"status": "deleted"}

@app.get("/data/{room}/{name}")
async def get_file(room: str, name: str):
    return FileResponse(os.path.join(DATA_DIR, room, name))

@app.get("/health")
async def health(): return {"status": "ok"}

rooms = {}
async def notify_room(room: str):
    if room in rooms:
        for ws in rooms[room]: await ws.send_text("UPDATE")

@app.websocket("/ws/{room}")
async def websocket_endpoint(websocket: WebSocket, room: str):
    await websocket.accept()
    if room not in rooms: rooms[room] = []
    rooms[room].append(websocket)
    try:
        while True: await websocket.receive_text()
    except WebSocketDisconnect:
        rooms[room].remove(websocket)

@app.get("/{full_path:path}")
async def serve_index():
    with open("index.html", "r") as f: return HTMLResponse(f.read())

if __name__ == "__main__":
    import uvicorn
    my_ip = get_local_ip()
    print(f"\n🚀 ARCHIVE IS LIVE\nNETWORK: http://{my_ip}:8000\n")
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="warning")