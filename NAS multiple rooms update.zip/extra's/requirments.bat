@echo off
echo Installing House-Hold Archive requirements...
python -m pip install --upgrade pip
python -m pip install fastapi uvicorn
echo.
echo ✅ All requirements installed successfully!
pause
