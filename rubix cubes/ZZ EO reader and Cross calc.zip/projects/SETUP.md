# GAN i4 F2L Trainer — setup

Two pieces:
- `index.html` — runs in Chrome, does the Bluetooth connection to your cube, tracks your moves, shows results, runs the "practice this solution" comparison. Nothing heavy happens here.
- `server.py` — a small local Flask server that wraps `or18/RubiksSolver` and does the actual cross/xcross/xxcross/xxxcross search. `index.html` calls it over `http://127.0.0.1:5000`.

They're separate because the solver's move/pruning tables run up to ~1.3 GB on disk and ~1.6 GB in RAM — that can't live in a browser tab, so it has to be a background process, exactly like you guessed.

## Windows: one-click setup

Just double-click **`start.bat`**.

That runs `setup_and_run.ps1`, which (each step skipped automatically if already done, so it's safe to run again later):
1. Downloads PyPy 3.11 into this folder (one time, ~50-60 MB) — no separate install, it just unzips.
2. Installs Flask into that PyPy.
3. Builds the solver tables under PyPy (one time, a few minutes instead of the "didn't finish in 3 minutes" you'd get under normal Python).
4. Starts `server.py` in its own window — **leave that window open** while you use the trainer, it's the backend.
5. Opens `index.html` in your default browser.

Next time, just double-click `start.bat` again — steps 1-3 are skipped since they're already done, so it just starts the server and opens the page, in a few seconds.

If Windows blocks the PowerShell script with a SmartScreen popup: click "More info" -> "Run anyway". It's not signed since it's a one-off script, not because it does anything unusual — you can open `setup_and_run.ps1` in Notepad first and read it if you want to check.

Everything below is the manual version of the same steps, useful if you're not on Windows or want to understand what the script is doing.

## 1. Install deps

```
pip install -r requirements.txt --break-system-packages   # or drop the flag if you're in a venv
```

`RubiksSolver/` (the solver package itself) is already included in this folder — no need to clone it separately.

## 2. (Recommended) Pre-build the tables once, with PyPy

Building the tables in normal CPython is slow — in testing, the xcross tables alone didn't finish in 3 minutes on plain CPython. The upstream project is built around PyPy3 for this reason. One-time setup:

```
# install pypy3.11 (pypy.org/download.html), then from this folder:
pypy3.11 prebuild_tables.py
```

This builds the cross + xcross tables for all 4 slots and saves them to `RubiksSolver/table/`. It only has to be done once, ever — after that, `server.py` (running under normal python is fine) just loads the cached files, which is fast.

If you skip this step, the first time you ask the app for a solve, `server.py` will build whatever tables that search needs, right then, under whatever Python it's running — which will be slow the first time and fast every time after.

xxcross/xxxcross tables aren't in `prebuild_tables.py` (they're bigger — build lazily the first time you request them, same one-time-slow-then-cached deal).

## 3. Run the server

```
python server.py
```

Leave this running in a terminal. It listens on `127.0.0.1:5000`.

## 4. Open index.html

Open it directly in Chrome (or Edge) — Web Bluetooth needs one of those. Click **Connect GAN Cube**, pick your cube. As you turn it, the "tracked moves" line fills in. Click **Mark cube as solved now** any time to zero that out (it also auto-resets when the cube reports a solved state).

Pick methods (cross/xcross/etc.), hit **Find best solutions**. Click any row to start practicing it — the move track below highlights green as you make each correct move on the physical cube, red if you deviate.

## About cleanup — short answer: no, you don't need to manually clean up anything

You asked whether you need to manually clean up after each calculation. You don't, for two different reasons depending on what you meant:

- **The table files in `RubiksSolver/table/`**: leave these alone, don't delete them. They're a cache, not scratch space — deleting them just makes the next solve slow again while they rebuild. `server.py` never touches them either.
- **Memory used during a search**: `server.py` calls `gc.collect()` after every `/solve` request (see the comment at the top of the file), which hands the RAM used by that search's table arrays back to the OS right away. Python's normal reference counting would eventually do this anyway; the explicit `gc.collect()` just makes it prompt instead of eventual, which matters here since the tables can be tens of MB per search. You don't need to restart the server between solves.

The one thing that *is* on you: if you ever want to reclaim the ~1.3 GB of disk the tables use (e.g. you're done with this project and need the space), that's just `rm -rf RubiksSolver/table/` — but there's no reason to do that while you're actively using the trainer.

## Notes / things you may want to tweak

- `server.py`'s `DEFAULT_MAX_LENGTH` dict controls how deep each search goes; raise it if a search comes back with no solution for a hard scramble.
- "Deep search" in the UI tries every slot combination at a given level (e.g. all 6 BL/BR/FR/FL pairs for xxcross) instead of just the first couple — much slower, but that's how you get the true best xxcross/xxxcross rather than just the best of the first slot(s) tried.
- `index.html` assumes `gan-web-bluetooth`'s MOVE events give WCA notation directly on `event.move` (matching your original file). If that's wrong for your library version, `normalizeMove()` has a fallback path you can adjust — check what shape `event` actually has by logging it once.
- The solved-state check compares facelets to a fixed `SOLVED_FACELETS` string in `U R F D L B` face order — if your cube reports a different sticker order, adjust that constant.

## About the "tracked moves never reset" bug (fixed)

Earlier version only asked the cube for its facelet state once, right after connecting, so it never noticed you'd re-solved it - moves just piled up forever. Fixed by asking the cube for its current facelets a moment after every move (debounced ~250ms so it's not spamming Bluetooth mid-turn) and comparing to solved; when it matches, everything resets automatically as if nothing happened. This assumes the cube's own facelet reporting is accurate - if it drifts after a very long session, "Mark cube as solved now" is there as a manual fallback.

## About the color-scheme setting

The Up/Front color dropdowns compute a whole-cube rotation (using the same `x`/`y`/`z` rotation notation RubiksSolver already supports) and send it along with every solve request, so the returned solution is phrased for how you actually hold the cube instead of the assumed default of White-up/Green-front. This assumes your cube was paired/calibrated while sitting White-up/Green-front, which is the GAN default - if your calibration itself was done in a different orientation, this setting rotates *on top of* that mismatch rather than fixing it, so double check the first solution or two before trusting it.

## Correction: the color-scheme setting no longer asks you to physically rotate

An earlier version sent your Up/Front choice to the backend as RubiksSolver's `rotation` parameter, which bakes the rotation in as a literal step you're meant to perform before the rest of the solution - that's backwards for what this is for (you'd end up back in White-top/Green-front, i.e. not your preference anymore), and since GAN i4 is gyro-stabilized, physically rotating the cube doesn't even change what letters it reports for subsequent moves - so that step did nothing useful and risked corrupting the tracked scramble if a face got bumped mid-rotation.

Fixed: the color-scheme choice is now a pure notation relabeling done entirely in `index.html` (see `computeFaceMap`/`relabelMove`). Every move event gets relabeled the moment it arrives - before it's shown, before it's sent to the backend as the scramble, and before it's compared during practice - so nothing you do to the physical cube changes, only which letters everything on screen uses. `server.py`'s `rotation` parameter is no longer used by the frontend (still there if you want to script against it directly).

Changing the Up/Front dropdowns mid-session resets tracked moves, since moves already tracked were labeled under the old choice and mixing the two would be wrong.

## Second correction: fixed a real direction bug, but your specific report needs one more check

My hand-derived rotation math had the direction backwards for the non-self-inverse rotations (`x`, `x'`, `y`, `y'`, `z`, `z'` - anything that isn't its own inverse). Verified this against RubiksSolver's own `AlgConvertRotation`/`AlgRotation` and replaced the whole thing with a literal 24-entry table generated directly from the library's own code (see `ROTATION_FACE_MAPS` in `index.html`), so there's no hand-derived geometry left to get wrong.

That said: Yellow-top/Blue-front specifically uses `x2`, which is its own inverse, so that particular case was already correct both before and after this fix - meaning a "cross off by a D2" symptom for that exact preference likely isn't this bug. The remaining suspect is the assumption that GAN i4's Bluetooth calibration = physical White-up/Green-front. If your cube was actually paired in a different orientation, everything inherits that fixed offset. `index.html` now has a quick check for this: solve the cube, set Up/Front correctly, turn your physical Up face once, and see whether "Tracked moves" says exactly "U". If not, that's the source, and the fix would be a proper calibration step rather than a color-preference one - worth confirming before digging further.

## Third correction: doubled quarter-turns (L then L instead of one L2)

The device reports each physical quarter-turn as its own MOVE event, even when you turn the same face twice in a row instead of doing one continuous half-turn - so "L then L" arrives as two separate `L` events, not one `L2`. The practice matcher used to compare each event individually against the target, so both looked like wrong moves against an expected `L2` (hence "off track by 2").

Fixed with a small buffer: consecutive turns on the same face accumulate (mod 4) and only commit as a single move once you turn a different face or pause for ~400ms - so L+L commits as `L2`, L+L' correctly cancels to nothing, and four quarters cancels out entirely. Moves on different faces still commit immediately, so normal algorithm execution has no added lag; the buffering only kicks in for same-face repeats.

## Fourth correction: the L-then-L merge shouldn't depend on speed

Right - whether two same-face turns merge into L2 should only depend on whether a different face got turned in between, never on how fast you did them. The 400ms window from the last fix was accidentally acting like a speed requirement instead of just being cleanup. Fixed: the merge now triggers purely on face-change (instant, no timing involved) - L then L is L2 whether you do it in a tenth of a second or wait ten seconds, as long as nothing else got turned first. There's still a timer (now 2.5s), but it's only a fallback so the very last move of a paused session eventually gets committed instead of waiting forever for a face-change that might never come - it's not what defines the merge.

Three same-direction turns (L,L,L) net to L' automatically (three quarters one way = one quarter the other way), and four nets to nothing, both already correct.

## Fifth correction: lag, and solved-detection still not firing

Two separate fixes:

1. **Duplicate subscriptions.** If Connect ever got triggered more than once for the same session (e.g. after a dropped/retried connection), each click stacked a brand new subscription to the cube's event stream on top of the old one - every subsequent physical move would then get processed twice, three times, etc., which both wastes CPU and can badly corrupt move tracking. Fixed: the Connect button now no-ops (and shows you're already connected) if a connection already exists, and any old subscription is explicitly unsubscribed before a new one is created.

2. **Solved-detection.** I've been assuming the exact string format the cube reports for a solved state (`"UUUUUUUUURRRRRRRRR..."` etc.) without ever being able to verify it against real hardware. There's now a small debug line under "Tracked moves" that shows the raw facelets string the cube actually reports (also logged to the browser console) - if the app still isn't detecting solves after this, check that line: it'll tell us immediately whether the format doesn't match what I assumed, which is the most likely remaining explanation. The comparison is also now trimmed and case-insensitive, in case it was just a stray whitespace/case mismatch.

Also reduced how often facelets get re-requested over Bluetooth (250ms -> 500ms debounce) to cut down on BLE traffic, though the duplicate-subscription bug was the more likely source of "really really bad" lag if it was happening.

## Sixth correction: removed all Bluetooth polling, tracks solved-state locally instead

The recurring `REQUEST_FACELETS` request I was sending after every move was extra outgoing Bluetooth traffic competing with the cube's own move notifications on the same connection - a very plausible reason turns occasionally weren't registering. It's also gone for a second reason: it depended on me correctly guessing the exact string format the device reports, which I was never able to verify.

Replaced entirely with a local simulation: `index.html` now ports RubiksSolver's own exact cubie-level move math (corner/edge permutation + orientation, straight from `RubiksSolver/move.py`) and tracks your cube's state purely by applying each committed move to a running state, checking for solved after every move. Verified this against known identities in both Python and the ported JS before shipping it: a sexy-move repeated six times returns to solved, and `L,L` produces the exact same state as `L2`. There is now **zero outgoing Bluetooth traffic** during normal use - the page only ever receives move notifications, never sends requests.

One tradeoff: this assumes you connect with the cube actually solved (or use "Mark cube as solved now" to (re)sync). If a physical move ever still gets dropped by the Bluetooth stack itself - which no amount of app-side code can fully rule out, since it's the device/OS deciding what gets delivered - the app has no way to know on its own. That's what the new debug line under "Tracked moves" is for: it shows whether the internal tracker currently believes the cube is solved, so if you've physically solved it and that line still says "not solved," you'll know immediately a move was missed rather than something else being wrong, and can resync with the button.
