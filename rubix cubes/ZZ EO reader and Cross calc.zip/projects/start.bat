@echo off
title GAN i4 F2L Trainer - Setup and Launch
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_and_run.ps1"
