"""
Backend solver server for the GAN i4 ZZ/CFOP trainer.

Why this exists as a separate Python process instead of running in the browser:
RubiksSolver (https://github.com/or18/RubiksSolver) does an IDA* search backed
by move/pruning tables that take up to ~1.3 GB on disk and ~1.6 GB of RAM once
loaded. That can't run in a browser tab, so the HTML page (index.html) only
handles Bluetooth + display, and calls this local server for the actual search.

Run it:
    pip install flask flask-cors
    python server.py
Then open index.html in Chrome (Web Bluetooth requires Chrome/Edge, and the
page must talk to http://127.0.0.1:5000).

ABOUT CLEANUP (read this if you're wondering whether you need to delete
anything between solves):
  - RubiksSolver/table/*  -> KEEP. These are the move/pruning tables. They are
    built once (slow, several minutes) and then reused forever. Deleting them
    just forces a slow rebuild next time you ask for a solve. This script
    never deletes them, and you shouldn't either.
  - In-process memory -> handled automatically. Each call to sv.solve_F2L()
    builds fresh Python array objects from those table files; once the
    request finishes and nothing references them anymore, normal refcounting
    frees them immediately. We additionally call gc.collect() after every
    request (see solve_one()) to hand freed memory back to the OS promptly,
    since the tables involved can be tens of MB per search. You do not need
    to restart the server or clear anything by hand between solves.
"""
import gc
import io
import sys
import time
import itertools
import contextlib
import traceback

from flask import Flask, request, jsonify
from flask_cors import CORS

import RubiksSolver.solver as sv
import RubiksSolver.move as mv

app = Flask(__name__)
CORS(app)  # index.html is opened as a local file / different origin

SLOTS = ["BL", "BR", "FR", "FL"]

# Reasonable default max search lengths per number of slots solved together.
# (cross=0 slots, xcross=1, xxcross=2, xxxcross=3, xxxxcross/F2L=4)
DEFAULT_MAX_LENGTH = {0: 8, 1: 10, 2: 13, 3: 15, 4: 17}

METHOD_LEVELS = {
    "cross": 0,
    "xcross": 1,
    "xxcross": 2,
    "xxxcross": 3,
    "xxxxcross": 4,
}


def flags_for_combo(combo):
    """combo is a tuple of slot names to solve, e.g. ('BL','FL'). Returns the
    four booleans solve_F2L expects, in BL,BR,FR,FL order."""
    return tuple(slot in combo for slot in SLOTS)


def run_search(scramble, flags, max_length, name, rotation=""):
    """Runs one solve_F2L search and extracts the solution from stdout
    (the library prints results rather than returning them in this mode)."""
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            sv.solve_F2L(
                scramble, rotation, flags[0], flags[1], flags[2], flags[3],
                max_length, False, 1, name, mv.move_UDLRFB,
            )
    finally:
        # Release the (potentially large) table arrays the search built.
        gc.collect()

    # The library also prints table-build progress ("start creating...",
    # "created ... table in Xs") before the actual result line, especially on
    # a cold cache. The result we want is the last line, and it always
    # contains "//" (either the solution, "// already solved", or
    # "// No solution for NAME").
    lines = [l for l in buf.getvalue().splitlines() if l.strip()]
    result_lines = [l for l in lines if "//" in l]
    out = result_lines[-1].strip() if result_lines else ""
    if not out:
        return None
    if out.startswith("//"):
        # "// already solved" or "// No solution for NAME"
        if "No solution" in out:
            return None
        return {"solution": "", "length": 0}
    # Format: "<solution moves> // <name> No.<idx>"
    solution = out.split("//")[0].strip()
    length = len([m for m in solution.split(" ") if m])
    return {"solution": solution, "length": length}


def solve_one(scramble, method, slots_filter=None, deep=False, rotation=""):
    """Solves `method` (cross/xcross/xxcross/xxxcross/xxxxcross), trying every
    valid combination of slots at that level (unless slots_filter restricts
    it), and returns the shortest solution found — i.e. the "best" one."""
    level = METHOD_LEVELS[method]
    max_length = DEFAULT_MAX_LENGTH[level]

    if level == 0:
        combos = [()]
    else:
        combos = list(itertools.combinations(SLOTS, level))
        if slots_filter:
            wanted = set(slots_filter)
            combos = [c for c in combos if set(c) <= wanted] or combos
        if not deep:
            # Quick mode: just try the first couple of combos instead of all
            # of them, to keep response times reasonable without PyPy.
            combos = combos[:2] if level >= 2 else combos

    results = []
    for combo in combos:
        flags = flags_for_combo(combo)
        label = method if level == 0 else f"{method} ({'+'.join(combo)})"
        r = run_search(scramble, flags, max_length, label, rotation)
        if r is not None:
            results.append({"label": label, "slots": list(combo), **r})

    results.sort(key=lambda r: r["length"])
    return results


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


@app.route("/solve", methods=["POST"])
def solve():
    data = request.get_json(force=True)
    scramble = (data.get("scramble") or "").strip()
    methods = data.get("methods") or ["cross", "xcross"]
    deep = bool(data.get("deep", False))
    rotation = (data.get("rotation") or "").strip()
    slots_filter = data.get("slots")  # optional list to restrict slots tried

    if not scramble:
        return jsonify({"error": "empty scramble - solve the cube / connect first"}), 400

    for m in methods:
        if m not in METHOD_LEVELS:
            return jsonify({"error": f"unknown method '{m}'"}), 400

    t0 = time.time()
    out = {}
    try:
        for method in methods:
            out[method] = solve_one(scramble, method, slots_filter, deep, rotation)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

    best_overall = None
    for method, results in out.items():
        if results:
            candidate = results[0]
            if best_overall is None or candidate["length"] < best_overall["length"]:
                best_overall = {"method": method, **candidate}

    return jsonify({
        "scramble": scramble,
        "elapsed": round(time.time() - t0, 3),
        "results": out,
        "best": best_overall,
    })


if __name__ == "__main__":
    print("Starting solver server on http://127.0.0.1:5000")
    print("First solve of each type will be slow while tables build in RubiksSolver/table/ (one-time, then cached).")
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=False)
