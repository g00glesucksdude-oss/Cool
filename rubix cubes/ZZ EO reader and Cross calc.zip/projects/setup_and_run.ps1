param()
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot

$pypyVersion = "pypy3.11-v7.3.23-win64"
$pypyZipUrl  = "https://downloads.python.org/pypy/$pypyVersion.zip"
$pypyDir     = Join-Path $root $pypyVersion
$pypyExe     = Join-Path $pypyDir "pypy.exe"

function Say($msg) { Write-Host "==> $msg" -ForegroundColor Cyan }

# 1. Get PyPy (skip if already downloaded/extracted from a previous run)
if (-not (Test-Path $pypyExe)) {
    Say "Downloading PyPy 3.11 (one-time, ~50-60 MB)..."
    $zipPath = Join-Path $root "$pypyVersion.zip"
    Invoke-WebRequest -Uri $pypyZipUrl -OutFile $zipPath
    Say "Extracting..."
    Expand-Archive -Path $zipPath -DestinationPath $root -Force
    Remove-Item $zipPath
} else {
    Say "PyPy already present, skipping download."
}

# 2. Make sure pip exists inside this PyPy, then install deps (skipped if already installed)
Say "Checking Python packages..."
& $pypyExe -m pip --version *> $null
if ($LASTEXITCODE -ne 0) {
    Say "Bootstrapping pip inside PyPy..."
    & $pypyExe -m ensurepip
}
& $pypyExe -m pip show flask *> $null
if ($LASTEXITCODE -ne 0) {
    Say "Installing flask + flask-cors into PyPy (one-time)..."
    & $pypyExe -m pip install flask flask-cors
} else {
    Say "Dependencies already installed, skipping."
}

# 3. Pre-build the cross/xcross tables if they aren't there yet (this is the slow-ish one-time step,
#    but MUCH faster under PyPy than under normal Python - a few minutes instead of a very long time)
Push-Location $root
$tableMarker = Join-Path $root "RubiksSolver\table\edge1618_edge2022_prune_table"
if (-not (Test-Path $tableMarker)) {
    Say "Building solver tables for the first time - this can take a few minutes, only happens once..."
    & $pypyExe prebuild_tables.py
} else {
    Say "Solver tables already built, skipping."
}

# 4. Start the backend server in its own window so it keeps running
Say "Starting solver server..."
Start-Process -FilePath $pypyExe -ArgumentList "server.py" -WorkingDirectory $root

# 5. Give it a moment to boot, then open the trainer page
Start-Sleep -Seconds 2
Say "Opening trainer page in your browser..."
Start-Process (Join-Path $root "index.html")

Say "All set. The solver server window must stay open while you use the trainer."
Say "Close that window (or Ctrl+C in it) when you're done."
Read-Host "Press Enter to close this setup window"
