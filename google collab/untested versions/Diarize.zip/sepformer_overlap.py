"""
sepformer_overlap.py
=====================
Standalone overlapping-speech separator, meant to be dropped into an
existing pipeline (e.g. your diarize_and_reassemble script) rather than
run on its own.

What it does NOT do: transcribe, diarize, or manage files. It only takes
audio + a list of overlap time-ranges and gives you back separated voice
tracks (numpy arrays) - or, if you pass it a transcribe callback, the
transcribed text for each separated voice.

Install:
    pip install speechbrain

Typical usage
-------------
    from sepformer_overlap import get_separator_model, find_overlap_regions, separate_overlap_clip

    separator = get_separator_model(device="cuda")  # loaded once, reuse across files

    # `turns` = list of {"start": float, "end": float, "speaker": str}
    # (this is exactly what whisperx.diarize.DiarizationPipeline / pyannote gives you)
    overlaps = find_overlap_regions(turns)

    for ov in overlaps:
        voices = separate_overlap_clip(audio, sample_rate, ov["start"], ov["end"], separator)
        # voices = list of numpy float32 arrays, one per separated speaker
        for voice_audio in voices:
            text = my_existing_transcribe_function(voice_audio)  # your Groq/local transcriber
            ...

Or use the all-in-one helper if you just want text back directly:

    results = separate_and_transcribe_overlaps(audio, sample_rate, overlaps, separator, my_transcribe_fn)
    # results = [{"start", "end", "speakers": (a,b), "texts": [text_voice1, text_voice2]}, ...]

Notes
-----
- Model: speechbrain/sepformer-whamr16k (trained at 16kHz - matches
  WhisperX's audio pipeline, no resampling needed if you're already at
  16kHz mono).
- separate_batch() expects a mono float32 tensor. If your audio is a
  different sample rate, resample the clip to 16000 Hz before calling
  separate_overlap_clip, or pass a different `source=` model to
  get_separator_model.
- This finds overlaps between DIFFERENT speakers only, and only
  time-overlapping turns from the diarization output - it does not
  itself detect overlap from raw audio.
- Only handles 2-speaker overlaps well (WHAMR is a 2-speaker mixture
  model). 3+ simultaneous speakers in one window will produce degraded
  separation.

Fixes for the five pipeline problems (see functions below)
------------------------------------------------------------
1. Speaker Disconnect      -> build_speaker_reference_embeddings() +
                               assign_speakers_to_voices() re-embed the
                               separated voices and match them back to
                               SPEAKER_00/SPEAKER_01 by cosine similarity
                               to reference clips, instead of guessing.
2. Out-of-Sync Subtitles   -> merge_overlap_entries_for_subtitles() turns
                               two identically-timestamped entries into
                               ONE valid cue with both speakers' lines
                               stacked, the way real closed captions
                               handle simultaneous dialogue.
3. Manifest Complexity     -> build_voice_manifest_entries() generates
                               the seg_0001_v1/_v2 sub-keys for you as
                               plain extra rows (with a `parent_segment`
                               back-pointer) so the manifest schema never
                               has to change shape.
4. VRAM Bottlenecks        -> overlap_resolution_session() context
                               manager loads SepFormer (+ the speaker
                               embedder, if needed) only for the
                               resolution step and guarantees unload on
                               exit, even on exception.
5. Redundant Transcription -> exclude_overlap_spans_from_segments() trims
                               overlap-covered time out of your MAIN
                               transcription pass so it's only
                               transcribed once, by SepFormer's cleaned
                               voices, not twice.

Full pipeline, each layer cleaned up before the next loads
------------------------------------------------------------
    with diarize_session(get_diarizer_model, unload_diarizer_model, device="cuda") as diarizer:
        turns = run_diarization(diarizer, audio)          # Pyannote freed on exit

    with transcribe_session(get_whisper_model, unload_whisper_model, device="cuda") as whisper:
        main_segments = run_transcription(whisper, audio, turns)   # Whisper freed on exit

    overlaps = find_overlap_regions(turns)
    main_segments = exclude_overlap_spans_from_segments(main_segments, overlaps)

    if overlaps:
        with overlap_resolution_session(device="cuda", need_embedder=True) as (separator, embedder):
            refs = build_speaker_reference_embeddings(audio, SAMPLE_RATE, turns, overlaps, embedder)
            results = []
            for ov in overlaps:
                voices = separate_overlap_clip(audio, SAMPLE_RATE, ov["start"], ov["end"], separator)
                if not voices:
                    continue
                texts = [(my_transcribe_fn(v) or "").strip() for v in voices]
                results.append({
                    "start": ov["start"], "end": ov["end"], "speakers": ov["speakers"],
                    "texts": texts,
                    "speaker_labels": assign_speakers_to_voices(voices, ov["speakers"], refs, embedder),
                })
        # SepFormer + embedder freed on exit

        overlap_cues = merge_overlap_entries_for_subtitles(results)
        final = sorted(main_segments + overlap_cues, key=lambda s: s["start"])
    else:
        final = main_segments
    # at no point were two heavy models resident in VRAM at once
"""

import gc
import itertools
from contextlib import contextmanager

import numpy as np
import torch

SAMPLE_RATE = 16000  # sepformer-whamr16k's expected input rate

_separator_model = None
_embedder_model = None


def get_separator_model(device: str = "cuda", cache_dir: str = "pretrained_models/sepformer-whamr16k"):
    """Loads (or returns the already-loaded) SepFormer separation model.
    Call once, reuse across files - reloading per-clip is wasteful."""
    global _separator_model
    if _separator_model is None:
        try:
            from speechbrain.inference.separation import SepformerSeparation
        except ImportError:
            from speechbrain.pretrained import SepformerSeparation  # SpeechBrain <1.0 fallback
        print("[+] Loading SepFormer speech-separation model (first run downloads ~1GB)...")
        _separator_model = SepformerSeparation.from_hparams(
            source="speechbrain/sepformer-whamr16k",
            savedir=cache_dir,
            run_opts={"device": device},
        )
    return _separator_model


def unload_separator_model():
    """Drop the model to free VRAM/RAM once you're done with a batch."""
    global _separator_model
    _separator_model = None
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def get_speaker_embedder(device: str = "cuda", cache_dir: str = "pretrained_models/spkrec-ecapa-voxceleb"):
    """Loads (or returns the already-loaded) speaker-embedding model used
    to match separated voices back to diarization speaker tags. Separate
    from get_separator_model() so you only pay for it (VRAM + load time)
    when you actually need speaker re-identification - see
    overlap_resolution_session()."""
    global _embedder_model
    if _embedder_model is None:
        try:
            from speechbrain.inference.speaker import EncoderClassifier
        except ImportError:
            from speechbrain.pretrained import EncoderClassifier  # SpeechBrain <1.0 fallback
        print("[+] Loading speaker-embedding model (first run downloads ~80MB)...")
        _embedder_model = EncoderClassifier.from_hparams(
            source="speechbrain/spkrec-ecapa-voxceleb",
            savedir=cache_dir,
            run_opts={"device": device},
        )
    return _embedder_model


def unload_speaker_embedder():
    """Drop the speaker-embedding model to free VRAM/RAM once you're done."""
    global _embedder_model
    _embedder_model = None
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


@contextmanager
def model_session(load_fn, unload_fn, *load_args, **load_kwargs):
    """Generic load -> use -> unload wrapper for ANY pipeline layer, not
    just this module's own models. Point it at whatever loader/unloader
    pair a layer already has (get_diarizer_model/unload_diarizer_model,
    get_whisper_model/unload_whisper_model, etc.) and it guarantees the
    model is dropped and VRAM is cleared when the block exits - including
    on exception - so no layer is left resident while the next one loads.

        with model_session(get_whisper_model, unload_whisper_model, device="cuda") as whisper:
            text = whisper.transcribe(clip)
        # whisper is unloaded here, before the next layer starts

    This is what overlap_resolution_session() below is built on; use the
    same pattern for the diarize and transcribe layers upstream of this
    module - see diarize_session()/transcribe_session() for drop-in
    templates you fill in with your actual Pyannote/Whisper calls.
    """
    model = load_fn(*load_args, **load_kwargs)
    try:
        yield model
    finally:
        unload_fn()


@contextmanager
def diarize_session(load_diarizer_fn, unload_diarizer_fn, *args, **kwargs):
    """Template for the DIARIZE layer (Pyannote or similar). Wire your
    existing get_diarizer_model()/unload_diarizer_model() functions in
    here - or just call model_session(load_diarizer_fn, unload_diarizer_fn, ...)
    directly wherever diarization happens - so the diarizer is guaranteed
    to be freed before the transcribe layer loads Whisper:

        with diarize_session(get_diarizer_model, unload_diarizer_model, device="cuda") as diarizer:
            turns = run_diarization(diarizer, audio)
        # diarizer freed here
    """
    with model_session(load_diarizer_fn, unload_diarizer_fn, *args, **kwargs) as diarizer:
        yield diarizer


@contextmanager
def transcribe_session(load_transcriber_fn, unload_transcriber_fn, *args, **kwargs):
    """Template for the TRANSCRIBE layer (Whisper or similar). Same
    pattern as diarize_session() - wire in your actual load/unload pair
    so Whisper is freed before overlap_resolution_session() loads
    SepFormer for layer 4:

        with transcribe_session(get_whisper_model, unload_whisper_model, device="cuda") as whisper:
            main_pass_segments = run_transcription(whisper, audio, turns)
        # whisper freed here, VRAM clear before SepFormer loads
    """
    with model_session(load_transcriber_fn, unload_transcriber_fn, *args, **kwargs) as transcriber:
        yield transcriber


@contextmanager
def overlap_resolution_session(device: str = "cuda", need_embedder: bool = False):
    """Scoped VRAM context for the whole overlap-resolution step. Loads
    SepFormer (and, if requested, the speaker embedder) on entry and
    unloads both on exit - even if the block raises - so you're never
    holding Pyannote + Whisper + SepFormer (+ embedder) in VRAM at once.
    Run this AFTER diarization/transcription are done and their models
    are unloaded, not alongside them:

        with overlap_resolution_session(need_embedder=True) as (separator, embedder):
            refs = build_speaker_reference_embeddings(audio, sr, turns, overlaps, embedder)
            results = separate_and_transcribe_overlaps(audio, sr, overlaps, separator, my_transcribe_fn)
            for r in results:
                r["speaker_labels"] = assign_speakers_to_voices(
                    [...voices...], r["speakers"], refs, embedder
                )
        # separator + embedder are freed here, before the next pipeline stage
    """
    with model_session(get_separator_model, unload_separator_model, device=device) as separator:
        if need_embedder:
            with model_session(get_speaker_embedder, unload_speaker_embedder, device=device) as embedder:
                yield separator, embedder
        else:
            yield separator, None


def _embed(audio_np: np.ndarray, embedder) -> np.ndarray:
    wav = torch.from_numpy(audio_np.astype(np.float32)).unsqueeze(0)
    with torch.no_grad():
        emb = embedder.encode_batch(wav)
    return emb.squeeze().detach().cpu().numpy()


def build_speaker_reference_embeddings(
    audio: np.ndarray,
    sample_rate: int,
    turns: list,
    overlaps: list,
    embedder,
    min_clip_dur: float = 1.0,
    max_clips_per_speaker: int = 3,
) -> dict:
    """Fix for Speaker Disconnect (part 1/2): builds one reference voice
    embedding per diarization speaker, using only their CLEAN (non-
    overlapping) turns - i.e. audio you already know is that speaker
    alone, no separation needed. Skips speakers with no clean turn long
    enough to embed reliably (they just won't get matched later).

    turns: same diarization turns you passed to find_overlap_regions().
    overlaps: the output of find_overlap_regions() (used to exclude any
        turn that touches an overlap window).

    Returns {speaker_label: np.ndarray} - a mean embedding per speaker.
    """
    if sample_rate != SAMPLE_RATE:
        raise ValueError(f"expects {SAMPLE_RATE} Hz audio (got {sample_rate} Hz). Resample first.")

    def touches_overlap(turn):
        for ov in overlaps:
            if turn["start"] < ov["end"] and turn["end"] > ov["start"]:
                return True
        return False

    by_speaker = {}
    for t in turns:
        if t["end"] - t["start"] < min_clip_dur:
            continue
        if touches_overlap(t):
            continue
        by_speaker.setdefault(t["speaker"], []).append(t)

    refs = {}
    for spk, clips in by_speaker.items():
        clips = sorted(clips, key=lambda c: c["end"] - c["start"], reverse=True)[:max_clips_per_speaker]
        embs = []
        for c in clips:
            s, e = int(c["start"] * sample_rate), int(c["end"] * sample_rate)
            embs.append(_embed(audio[s:e], embedder))
        if embs:
            refs[spk] = np.mean(embs, axis=0)
    return refs


def assign_speakers_to_voices(voices: list, expected_speakers: tuple, speaker_refs: dict, embedder) -> list:
    """Fix for Speaker Disconnect (part 2/2): matches SepFormer's
    unlabeled separated voices back to SPEAKER_00/SPEAKER_01 (etc.)
    instead of guessing the assignment. Embeds each separated voice and
    picks the permutation against `expected_speakers`' reference
    embeddings (from build_speaker_reference_embeddings) that maximizes
    total cosine similarity - i.e. proper (if small, 2-way) assignment
    rather than a greedy/positional guess.

    expected_speakers: the ov["speakers"] tuple for this region, i.e. the
        two diarization labels find_overlap_regions() said were involved.

    Returns a list the same length as `voices`, each entry either the
    matched speaker label or None if there wasn't enough reference data
    to match confidently (e.g. one of the two speakers had no clean
    turns anywhere in the file).
    """
    candidates = [s for s in expected_speakers if s in speaker_refs]
    if len(candidates) < 2:
        return [None] * len(voices)

    voice_embs = [_embed(v, embedder) for v in voices]

    def cos(a, b):
        return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-8))

    n = min(len(voice_embs), len(candidates))
    best_perm, best_score = None, -1e9
    for perm in itertools.permutations(range(len(candidates)), n):
        total = sum(cos(voice_embs[i], speaker_refs[candidates[perm[i]]]) for i in range(n))
        if total > best_score:
            best_score, best_perm = total, perm

    labels = [None] * len(voices)
    for i, cand_idx in enumerate(best_perm):
        labels[i] = candidates[cand_idx]
    return labels


def merge_overlap_entries_for_subtitles(entries: list, epsilon: float = 0.05) -> list:
    """Fix for Out-of-Sync Subtitles: standard SRT/TXT compilers render
    entries sequentially, so two voices both spanning 12.40s-14.10s become
    two back-to-back entries with IDENTICAL timestamps - which breaks
    strict SRT parsers and overlaps visually in players. This instead
    collapses each overlap region into a SINGLE valid cue spanning
    start-end, with each speaker's line stacked on its own line inside
    that one cue - the same way professional closed captions render
    simultaneous dialogue.

    entries: the list returned by separate_and_transcribe_overlaps(),
        optionally with a "speaker_labels" key added (same length/order
        as "texts") from assign_speakers_to_voices() - falls back to
        "Voice 1"/"Voice 2" if that key is absent or has Nones.

    Returns a list of {"start", "end", "text"} ready to splice into your
    final subtitle compiler IN PLACE of the individual per-voice entries
    for that region (don't emit both - see exclude_overlap_spans_from_segments
    for keeping the main pass from double-covering the same span).
    """
    merged = []
    for e in entries:
        raw_labels = e.get("speaker_labels") or [None] * len(e["texts"])
        labels = [lbl or f"Voice {i + 1}" for i, lbl in enumerate(raw_labels)]
        lines = [f"[{lbl}] {txt}" for lbl, txt in zip(labels, e["texts"]) if txt]
        if not lines:
            continue
        merged.append({
            "start": e["start"],
            "end": max(e["end"], e["start"] + epsilon),
            "text": "\n".join(lines),
        })
    return merged


def make_voice_subsegment_keys(parent_segment_id: str, num_voices: int) -> list:
    """Fix for Manifest Complexity (part 1/2): deterministic sub-keys for
    a segment split into N separated voices, e.g. make_voice_subsegment_keys("seg_0001", 2)
    -> ["seg_0001_v1", "seg_0001_v2"]."""
    return [f"{parent_segment_id}_v{i + 1}" for i in range(num_voices)]


def build_voice_manifest_entries(parent_segment_id: str, parent_entry: dict, num_voices: int) -> list:
    """Fix for Manifest Complexity (part 2/2): expands one manifest
    segment into N manifest-entry dicts for its separated voices, WITHOUT
    changing manifest.json's schema - each new entry is a shallow copy of
    the parent (same metadata) plus `parent_segment` and `voice_index`
    keys, so code downstream that expects "one manifest entry == one
    audio file == one text output" keeps working unmodified; it just sees
    more rows, addressable by seg_0001_v1.wav / seg_0001_v2.wav.

    Append the returned entries to manifest["segments"] in place of (or
    alongside, if you want to keep the mixed original too) parent_entry.
    """
    keys = make_voice_subsegment_keys(parent_segment_id, num_voices)
    entries = []
    for i, key in enumerate(keys):
        entry = dict(parent_entry)
        entry["segment_id"] = key
        entry["parent_segment"] = parent_segment_id
        entry["voice_index"] = i
        entry["audio_file"] = f"{parent_segment_id}_v{i + 1}.wav"
        entries.append(entry)
    return entries


def exclude_overlap_spans_from_segments(segments: list, overlaps: list, min_remaining: float = 0.15) -> list:
    """Fix for Redundant Transcriptions: trims (or drops) segments from
    your MAIN transcription pass wherever they cover time already claimed
    by an overlap region, so that time is transcribed exactly once - by
    SepFormer's separated, cleaner voices via separate_and_transcribe_overlaps
    - instead of twice (once blurrily on the mixed audio in the main
    pass, once cleanly on the isolated voices).

    Call this on your main-pass segments BEFORE compiling the final
    output, then splice in merge_overlap_entries_for_subtitles()'s output
    for the excluded spans. A segment fully inside an overlap region is
    dropped; a segment that only partially overlaps is trimmed to
    whichever non-overlapping remainder (if any) is >= min_remaining.
    """
    def overlapping_span(seg):
        for ov in overlaps:
            lo, hi = max(seg["start"], ov["start"]), min(seg["end"], ov["end"])
            if hi > lo:
                return lo, hi
        return None

    out = []
    for seg in segments:
        span = overlapping_span(seg)
        if span is None:
            out.append(seg)
            continue
        lo, hi = span
        before, after = dict(seg), dict(seg)
        before["end"], after["start"] = lo, hi
        if before["end"] - before["start"] >= min_remaining:
            out.append(before)
        if after["end"] - after["start"] >= min_remaining:
            out.append(after)
    return out


def find_overlap_regions(turns: list, min_overlap: float = 0.3) -> list:
    """turns: list of {"start": float, "end": float, "speaker": str},
    e.g. straight from whisperx.diarize.DiarizationPipeline's dataframe
    (df[["start","end","speaker"]].to_dict("records")) or a pyannote
    Annotation converted the same way.

    Returns list of {"start", "end", "speakers": (spk_a, spk_b)} for every
    pair of different-speaker turns that overlap by at least min_overlap
    seconds.
    """
    sorted_turns = sorted(turns, key=lambda t: t["start"])
    overlaps = []
    for i in range(len(sorted_turns)):
        for j in range(i + 1, len(sorted_turns)):
            a, b = sorted_turns[i], sorted_turns[j]
            if b["start"] >= a["end"]:
                continue
            if a["speaker"] == b["speaker"]:
                continue
            ov_start = max(a["start"], b["start"])
            ov_end = min(a["end"], b["end"])
            if ov_end - ov_start >= min_overlap:
                overlaps.append({"start": ov_start, "end": ov_end, "speakers": (a["speaker"], b["speaker"])})
    return overlaps


def separate_overlap_clip(audio: np.ndarray, sample_rate: int, start: float, end: float, separator) -> list:
    """Slices [start:end] out of `audio` (must already be `sample_rate`,
    mono, float32) and runs it through the separator.

    Returns a list of numpy float32 arrays, one per separated voice
    (typically 2). Empty list if the clip is too short or separation fails.
    """
    if sample_rate != SAMPLE_RATE:
        raise ValueError(
            f"separate_overlap_clip expects {SAMPLE_RATE} Hz audio (got {sample_rate} Hz). "
            "Resample the clip first, or load a different SepFormer checkpoint for your rate."
        )

    start_sample = max(0, int(start * sample_rate))
    end_sample = min(len(audio), int(end * sample_rate))
    if end_sample - start_sample < int(0.2 * sample_rate):
        return []

    clip = audio[start_sample:end_sample].astype(np.float32)
    mix = torch.from_numpy(clip).float().unsqueeze(0)  # [1, time]

    try:
        with torch.no_grad():
            est_sources = separator.separate_batch(mix)  # [1, time, num_speakers]
    except Exception as e:
        print(f"[!] separation failed on {start:.2f}s-{end:.2f}s ({e})")
        return []

    voices = []
    for spk_idx in range(est_sources.shape[-1]):
        voice = est_sources[0, :, spk_idx].detach().cpu().numpy().reshape(-1)
        peak = np.max(np.abs(voice))
        if peak > 0:
            voice = voice / peak * 0.9  # normalize so it's not near-silent going into a transcriber
        voices.append(voice.astype(np.float32))
    return voices


def splice_overlaps_into_audio(audio: np.ndarray, sample_rate: int, overlap_regions: list, separator) -> tuple:
    """PRE-DIARIZATION step. Takes raw audio + a list of {"start", "end"}
    overlap regions (from an overlap detector, e.g. pyannote OSD - no
    speaker IDs needed here), separates each region with SepFormer, and
    splices the separated voices in SEQUENTIALLY (one after another) in
    place of the original overlapping chunk.

    This necessarily makes the output audio LONGER than the input by
    (num_voices - 1) * region_duration for every region spliced, so every
    timestamp after a splice point drifts relative to the original file.
    That drift is fully recorded in the returned manifest so it can be
    undone later with spliced_time_to_original().

    overlap_regions: list of {"start": float, "end": float}, sorted or not
        (this function sorts them internally).

    Returns (new_audio: np.ndarray, manifest: dict). Pass new_audio into
    your diarizer as normal; keep manifest to reverse-map timestamps once
    you have transcript segments back from the diarize->chunk->transcribe
    steps.

    manifest format:
    {
      "sample_rate": 16000,
      "splices": [
        {
          "original_start": 12.40, "original_end": 13.10,
          "spliced_start": 12.40, "spliced_end": 13.80,
          "num_voices": 2
        },
        ...
      ]
    }
    Splices are stored in order of original_start; spliced_start/end are
    in the NEW audio's timeline.
    """
    if sample_rate != SAMPLE_RATE:
        raise ValueError(f"expects {SAMPLE_RATE} Hz audio (got {sample_rate} Hz). Resample first.")

    regions = sorted(overlap_regions, key=lambda r: r["start"])
    manifest = {"sample_rate": sample_rate, "splices": []}

    out_chunks = []
    cursor = 0.0  # position in ORIGINAL audio we've copied up to, in seconds
    out_len_sec = 0.0  # running length of OUTPUT audio built so far, in seconds

    for region in regions:
        r_start, r_end = region["start"], region["end"]
        if r_start < cursor:
            print(f"[!] skipping overlapping/out-of-order region {r_start:.2f}-{r_end:.2f} "
                  f"(cursor already at {cursor:.2f})")
            continue

        # 1. copy untouched audio from cursor up to this region, unchanged
        gap_start_sample = int(cursor * sample_rate)
        gap_end_sample = int(r_start * sample_rate)
        if gap_end_sample > gap_start_sample:
            gap = audio[gap_start_sample:gap_end_sample]
            out_chunks.append(gap)
            out_len_sec += len(gap) / sample_rate

        # 2. separate this region into N voices, splice them in sequentially
        voices = separate_overlap_clip(audio, sample_rate, r_start, r_end, separator)
        if not voices:
            # separation failed/too short - just pass the original mixed audio through untouched
            raw_start_sample = int(r_start * sample_rate)
            raw_end_sample = int(r_end * sample_rate)
            raw = audio[raw_start_sample:raw_end_sample]
            out_chunks.append(raw)
            out_len_sec += len(raw) / sample_rate
            cursor = r_end
            continue

        spliced_start = out_len_sec
        for voice in voices:
            out_chunks.append(voice)
            out_len_sec += len(voice) / sample_rate
        spliced_end = out_len_sec

        manifest["splices"].append({
            "original_start": r_start,
            "original_end": r_end,
            "spliced_start": spliced_start,
            "spliced_end": spliced_end,
            "num_voices": len(voices),
        })

        cursor = r_end

    # 3. copy whatever's left after the last region
    tail_start_sample = int(cursor * sample_rate)
    if tail_start_sample < len(audio):
        out_chunks.append(audio[tail_start_sample:])

    new_audio = np.concatenate(out_chunks) if out_chunks else audio.copy()
    return new_audio, manifest


def spliced_time_to_original(t: float, manifest: dict) -> float:
    """Reverse-maps a single timestamp `t` (in the SPLICED audio's
    timeline - e.g. a segment start/end coming back from your diarizer or
    transcriber, which ran on the spliced audio) back to the equivalent
    timestamp in the ORIGINAL audio's timeline.

    Call this on every segment boundary you get back from diarization/
    transcription before writing the final txt/srt.
    """
    cumulative_delta = 0.0  # how much longer spliced audio is than original, up to this point
    for splice in manifest["splices"]:
        s_start, s_end = splice["spliced_start"], splice["spliced_end"]
        o_start, o_end = splice["original_start"], splice["original_end"]
        original_region_dur = o_end - o_start
        num_voices = splice["num_voices"]

        if t < s_start:
            # t is before this splice entirely - no more deltas apply, we're done
            return t - cumulative_delta

        if s_start <= t < s_end:
            # t falls inside this spliced (multi-voice) region.
            # Figure out which voice-chunk it's in, then map that chunk's
            # internal offset straight back onto the original region -
            # every voice chunk represents the SAME original time window.
            offset_into_splice = t - s_start
            voice_idx = min(int(offset_into_splice // original_region_dur), num_voices - 1)
            offset_into_voice = offset_into_splice - (voice_idx * original_region_dur)
            offset_into_voice = min(offset_into_voice, original_region_dur)
            return o_start + offset_into_voice

        # t is past this splice - accumulate its added duration and keep going
        inserted = (s_end - s_start) - original_region_dur
        cumulative_delta += inserted

    # t is after every splice
    return t - cumulative_delta


def remap_segments_to_original(segments: list, manifest: dict) -> list:
    """Convenience wrapper: takes transcript segments in the SPLICED
    timeline (e.g. [{"start", "end", "speaker", "text"}, ...] straight out
    of your diarize -> chunk -> transcribe steps) and returns the same
    list with "start"/"end" rewritten back into the ORIGINAL timeline,
    ready to compile into a final txt/srt. Sorted by original start time.
    """
    remapped = []
    for seg in segments:
        new_seg = dict(seg)
        new_seg["start"] = spliced_time_to_original(seg["start"], manifest)
        new_seg["end"] = spliced_time_to_original(seg["end"], manifest)
        remapped.append(new_seg)
    remapped.sort(key=lambda s: s["start"])
    return remapped


def separate_and_transcribe_overlaps(
    audio: np.ndarray,
    sample_rate: int,
    overlaps: list,
    separator,
    transcribe_fn,
) -> list:
    """Convenience all-in-one: separates every overlap region and runs
    `transcribe_fn(voice_audio: np.ndarray) -> str` on each resulting voice.

    Returns list of {"start", "end", "speakers": (a,b), "texts": [str, ...]}
    - one entry per overlap region, texts in the same order as the
      separated voices (order is NOT guaranteed to correspond to
      speakers[0]/speakers[1] - SepFormer doesn't preserve speaker identity,
      it just gives you N separated streams).
    """
    results = []
    for idx, ov in enumerate(overlaps, start=1):
        print(f"[+] overlap {idx}/{len(overlaps)}: {ov['start']:.2f}s-{ov['end']:.2f}s "
              f"({ov['speakers'][0]} + {ov['speakers'][1]})")
        voices = separate_overlap_clip(audio, sample_rate, ov["start"], ov["end"], separator)
        if not voices:
            continue
        texts = []
        for voice_audio in voices:
            try:
                text = (transcribe_fn(voice_audio) or "").strip()
            except Exception as e:
                print(f"    [!] transcribe_fn failed on a separated voice ({e})")
                text = ""
            if text:
                texts.append(text)
        if texts:
            results.append({"start": ov["start"], "end": ov["end"], "speakers": ov["speakers"], "texts": texts})
    return results
