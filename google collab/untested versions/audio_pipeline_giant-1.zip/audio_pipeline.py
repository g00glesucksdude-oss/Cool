#!/usr/bin/env python3
"""
AUDIO PIPELINE GIANT
====================

Purpose
-------
Stage 1:
  - accept a pool of local audio files OR one URL/ZIP
  - normalize and splice them in deterministic order
  - optionally diarize speakers with pyannote Community-1
  - build pause/speaker-aware segments
  - write a manifest describing every segment

Stage 2:
  - Groq mode embeds the important behavior from the user's Groq transcriber:
      * turbo short pause chunks + per-chunk language redetection
      * large-v3 ~15 minute pause-snapped chunks
      * 24 MiB hard upload safety ceiling
      * API-key cycling
      * cooldown after 429/401/403/quota errors
      * progress/resume
      * running context and language-switch context reset
      * optional translation
  - Colab mode keeps the important behavior from the user's Colab transcriber:
      * faster-whisper
      * Turbo ~25 second language-aware segments
      * large-v3 whole-file pass
      * Drive state/resume when actually running in Colab
      * GPU-aware model selection
      * link/ZIP acquisition helpers

Paranoia rules
--------------
- Never silently overwrite an existing project.
- Every generated segment has source/combined timestamps and a stable ID.
- Segment bounds are validated before export.
- Groq chunks are size-checked as FLAC and recursively split if > 24 MiB.
- State is written atomically.
- Source files are never deleted.
- Failed transcription chunks are not silently treated as successful.
- A final manifest is only marked complete after all requested work succeeds.
"""

from __future__ import annotations

# ============================================================
# COLAB SELF-INSTALLER
# Paste this ENTIRE file into one Google Colab cell and run it.
# It installs the required Python packages before importing them.
# FFmpeg is also installed when running in Colab.
# ============================================================

REQUIREMENTS = [
    "pydub", "groq", "faster-whisper", "pyannote.audio", "deep-translator", "torch"
]

IN_COLAB = False
try:
    import google.colab  # type: ignore
    IN_COLAB = True
except Exception:
    IN_COLAB = False

if IN_COLAB:
    import subprocess as _bootstrap_subprocess
    import sys as _bootstrap_sys
    # Colab already provides a compatible torch in normal runtimes; avoid
    # needlessly replacing it while still documenting torch as a requirement.
    _colab_requirements = [x for x in REQUIREMENTS if x != "torch"]
    _bootstrap_subprocess.run([_bootstrap_sys.executable, "-m", "pip", "install", "-q",
        *_colab_requirements], check=True)
    _bootstrap_subprocess.run(["apt-get", "update", "-qq"], check=True)
    _bootstrap_subprocess.run(["apt-get", "install", "-y", "-qq", "ffmpeg", "unzip"], check=True)


import argparse
import gc
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import http.cookiejar
import urllib.request
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Optional

# ----------------------------
# CORE CONFIG
# ----------------------------

APP_VERSION = "2.0-paranoid"
SAMPLE_RATE = 16000
CHANNELS = 1

# Original Groq behavior.
GROQ_MODEL_IDS = {"turbo": "whisper-large-v3-turbo", "large": "whisper-large-v3"}
GROQ_MAX_CHUNK_MS = 45 * 1000
GROQ_MIN_CHUNK_MS = 3 * 1000
GROQ_SEARCH_WINDOW_MS = 8 * 1000
GROQ_MIN_SILENCE_LEN = 200
GROQ_SILENCE_THRESH_OFFSET = -16
GROQ_LARGE_TARGET_CHUNK_MS = 15 * 60 * 1000
GROQ_LARGE_SEARCH_WINDOW_MS = 30 * 1000
GROQ_LARGE_MIN_SILENCE_LEN = 400
GROQ_LARGE_SILENCE_THRESH_OFFSET = -16
GROQ_MAX_CHUNK_BYTES = 24 * 1024 * 1024
GROQ_RATE_LIMIT_COOLDOWN_SEC = 3
GROQ_TRANSLATE_CHUNK_CHARS = 4500

# Original Colab Turbo behavior.
COLAB_LANG_MAX_SEGMENT_MS = 25 * 1000
COLAB_LANG_MIN_SEGMENT_MS = 2 * 1000
COLAB_LANG_SEGMENT_SEARCH_MS = 5 * 1000
COLAB_LANG_MIN_SILENCE_LEN = 200
COLAB_LANG_SILENCE_THRESH_OFFSET = -16

AUDIO_EXTS = {".ogg", ".oga", ".mp3", ".wav", ".m4a", ".flac", ".mp4", ".webm", ".mpeg", ".mpga"}
PYANNOTE_MODEL = "pyannote/speaker-diarization-community-1"

# ----------------------------
# UTILITIES
# ----------------------------

def atomic_json_write(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def unified_progress_path(project: Path) -> Path:
    return project / "pipeline_progress.json"

def update_unified_progress(project: Path, backend: str, **fields):
    """Single shared progress ledger for BOTH Groq and Colab.
    Backend-specific state is retained, so switching backends can resume without
    destroying the other backend's progress.
    """
    path = unified_progress_path(project)
    try:
        state = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except Exception:
        state = {}
    state.setdefault("backends", {})
    state["active_backend"] = backend
    state["updated_at"] = time.time()
    state["backends"].setdefault(backend, {})
    state["backends"][backend].update(fields)
    atomic_json_write(path, state)
    return state

def sha256_file(path: Path, block=1024 * 1024) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(block)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def safe_name(name: str) -> str:
    name = os.path.basename(name)
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", name).strip(" .")
    return name or "audio"


def ask(prompt: str, default: Optional[str] = None) -> str:
    suffix = f" [{default}]" if default is not None else ""
    value = input(prompt + suffix + ": ").strip()
    return value if value else (default or "")


def yes_no(prompt: str, default=True) -> bool:
    d = "Y/n" if default else "y/N"
    while True:
        v = input(f"{prompt} [{d}]: ").strip().lower()
        if not v:
            return default
        if v in ("y", "yes"):
            return True
        if v in ("n", "no"):
            return False


def duration_label(ms: int) -> str:
    s = ms / 1000
    if s < 60:
        return f"{s:.1f}s"
    return f"{s/60:.2f}m"


def run_ffmpeg(args: list[str]):
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *args], check=True)


# ----------------------------
# URL / DOWNLOAD
# ----------------------------

def safe_encode_url(url: str) -> str:
    from urllib.parse import urlsplit, urlunsplit, quote
    parts = urlsplit(url.strip())
    path = quote(parts.path, safe="/%")
    query = quote(parts.query, safe="=&%")
    return urlunsplit((parts.scheme, parts.netloc, path, query, parts.fragment))


def guess_filename(url: str, headers) -> str:
    import re
    from urllib.parse import urlparse
    cd = headers.get("Content-Disposition", "")
    match = re.search(r'filename\*?=(?:UTF-8\'\')?"?([^";\n]+)"?', cd)
    if match:
        return safe_name(match.group(1).strip())
    return safe_name(os.path.basename(urlparse(url).path) or "downloaded_file")


def resolve_mediafire(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as resp:
        html = resp.read().decode("utf-8", errors="ignore")
    patterns = [
        r'href="(https?://download[^"]+)"',
        r'id="downloadButton"[^>]*href="([^"]+)"',
        r'"downloadUrl"\s*:\s*"([^"]+)"',
    ]
    for pattern in patterns:
        m = re.search(pattern, html)
        if m:
            return safe_encode_url(m.group(1).replace("\\/", "/"))
    raise ValueError("Could not resolve MediaFire direct download URL.")


def extract_gdrive_id(url: str) -> Optional[str]:
    m = re.search(r"/file/d/([^/]+)", url) or re.search(r"[?&]id=([^&]+)", url)
    return m.group(1) if m else None


def download_from_gdrive(file_id: str, dest: Path) -> str:
    jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    base = "https://drive.google.com/uc?export=download"
    resp = opener.open(f"{base}&id={file_id}")
    content_type = resp.headers.get("Content-Type", "")
    if "text/html" in content_type:
        html = resp.read().decode("utf-8", errors="ignore")
        token_match = re.search(r'confirm=([0-9A-Za-z_-]+)', html)
        uuid_match = re.search(r'name="uuid" value="([^"]+)"', html)
        if uuid_match:
            confirm_match = re.search(r'name="confirm" value="([^"]+)"', html)
            confirm_val = confirm_match.group(1) if confirm_match else "t"
            resp = opener.open(
                f"https://drive.usercontent.google.com/download?id={file_id}"
                f"&export=download&confirm={confirm_val}&uuid={uuid_match.group(1)}"
            )
        elif token_match:
            resp = opener.open(f"{base}&id={file_id}&confirm={token_match.group(1)}")
    if "text/html" in resp.headers.get("Content-Type", ""):
        raise ValueError("Google Drive returned HTML instead of the file; check link sharing.")
    with open(dest, "wb") as out:
        shutil.copyfileobj(resp, out)
    return guess_filename(f"{base}&id={file_id}", resp.headers)


def download_link(url: str, dest: Path) -> str:
    url = safe_encode_url(url)
    if "drive.google.com" in url:
        fid = extract_gdrive_id(url)
        if not fid:
            raise ValueError("Could not find Google Drive file ID.")
        return download_from_gdrive(fid, dest)
    if "mediafire.com" in url and "/file/" in url:
        url = resolve_mediafire(url)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as resp:
        fname = guess_filename(url, resp.headers)
        with open(dest, "wb") as out:
            shutil.copyfileobj(resp, out)
    return fname


def acquire_inputs(project: Path, paths: list[str], url: Optional[str]) -> list[Path]:
    incoming = project / "incoming"
    incoming.mkdir(exist_ok=True)
    extracted = project / "source_audio"
    extracted.mkdir(exist_ok=True)

    if url:
        download_path = incoming / "downloaded_input"
        print("[+] Downloading source...")
        suggested = download_link(url, download_path)
        if not download_path.exists() or download_path.stat().st_size == 0:
            raise RuntimeError("Download failed or was empty.")
        if zipfile.is_zipfile(download_path):
            print("[+] ZIP detected; extracting audio files...")
            with zipfile.ZipFile(download_path) as z:
                # Safe extraction: reject path traversal.
                for member in z.infolist():
                    target = (extracted / member.filename).resolve()
                    if not str(target).startswith(str(extracted.resolve()) + os.sep):
                        raise RuntimeError(f"Unsafe ZIP path rejected: {member.filename}")
                z.extractall(extracted)
            files = sorted(p for p in extracted.rglob("*") if p.is_file() and p.suffix.lower() in AUDIO_EXTS)
        else:
            ext = Path(suggested).suffix.lower()
            if ext not in AUDIO_EXTS:
                raise ValueError(f"Downloaded item is not a supported audio file or ZIP: {suggested}")
            target = extracted / safe_name(suggested)
            shutil.move(str(download_path), target)
            files = [target]
        if not files:
            raise ValueError("No supported audio files found in the downloaded ZIP.")
        return files

    files = []
    for raw in paths:
        p = Path(raw).expanduser().resolve()
        if p.is_file() and p.suffix.lower() in AUDIO_EXTS:
            files.append(p)
        elif p.is_dir():
            files.extend(sorted(x for x in p.rglob("*") if x.is_file() and x.suffix.lower() in AUDIO_EXTS))
        else:
            print(f"[!] Ignoring missing/unsupported input: {p}")
    if not files:
        raise ValueError("No audio files found.")
    return files


# ----------------------------
# AUDIO / SPLICING
# ----------------------------

def load_audio(path: Path):
    from pydub import AudioSegment
    return AudioSegment.from_file(path).set_frame_rate(SAMPLE_RATE).set_channels(CHANNELS)


def splice_sources(files: list[Path], out_wav: Path) -> tuple[list[dict], int]:
    from pydub import AudioSegment
    combined = AudioSegment.empty()
    sources = []
    pos = 0
    for idx, p in enumerate(files, 1):
        print(f"[+] Splicing {idx}/{len(files)}: {p.name}")
        audio = load_audio(p)
        start = pos
        end = pos + len(audio)
        combined += audio
        sources.append({
            "index": idx,
            "path": str(p.resolve()),
            "name": p.name,
            "start_ms": start,
            "end_ms": end,
            "duration_ms": len(audio),
            "sha256": sha256_file(p),
        })
        pos = end
    combined.export(out_wav, format="wav")
    return sources, len(combined)


# ----------------------------
# SILENCE CHUNKING
# ----------------------------

def detect_pause_centers(audio, min_silence_len: int, offset_db: float) -> list[int]:
    from pydub.silence import detect_silence
    if len(audio) == 0:
        return []
    # dBFS can be -inf for absolute silence. Keep threshold finite.
    base = audio.dBFS
    if not math.isfinite(base):
        base = -60.0
    thresh = base + offset_db
    silences = detect_silence(audio, min_silence_len=min_silence_len, silence_thresh=thresh)
    return [(s + e) // 2 for s, e in silences]


def build_pause_chunks(audio, target_ms: int, min_ms: int, search_ms: int,
                       min_silence_len: int, offset_db: float) -> list[tuple[int,int]]:
    pauses = detect_pause_centers(audio, min_silence_len, offset_db)
    out = []
    pos = 0
    total = len(audio)
    while pos < total:
        target = min(pos + target_ms, total)
        if target >= total:
            cut = total
        else:
            candidates = [p for p in pauses if pos + min_ms <= p <= target + search_ms]
            cut = min(candidates, key=lambda p: abs(p - target)) if candidates else target
        if cut <= pos:
            cut = min(pos + min_ms, total)
        out.append((pos, cut))
        pos = cut
    return out


def build_groq_turbo_chunks(audio) -> list[tuple[int,int]]:
    # This intentionally mirrors the original Groq turbo "earliest valid pause"
    # behavior rather than the generic target-length builder.
    pauses = detect_pause_centers(audio, GROQ_MIN_SILENCE_LEN, GROQ_SILENCE_THRESH_OFFSET)
    out, pos, total = [], 0, len(audio)
    while pos < total:
        eligible = [p for p in pauses if pos + GROQ_MIN_CHUNK_MS <= p <= pos + GROQ_MAX_CHUNK_MS]
        if eligible:
            cut = eligible[0]
        else:
            beyond = [p for p in pauses if pos + GROQ_MIN_CHUNK_MS <= p <= pos + GROQ_MAX_CHUNK_MS + GROQ_SEARCH_WINDOW_MS]
            cut = beyond[0] if beyond else min(pos + GROQ_MAX_CHUNK_MS, total)
        cut = min(cut, total)
        if cut <= pos:
            cut = min(pos + GROQ_MIN_CHUNK_MS, total)
        out.append((pos, cut))
        pos = cut
    return out


def build_groq_large_chunks(audio) -> list[tuple[int,int]]:
    # Original large-v3 target/search behavior.
    pauses = detect_pause_centers(audio, GROQ_LARGE_MIN_SILENCE_LEN, GROQ_LARGE_SILENCE_THRESH_OFFSET)
    out, pos, total = [], 0, len(audio)
    while pos < total:
        target = min(pos + GROQ_LARGE_TARGET_CHUNK_MS, total)
        if target >= total:
            cut = total
        else:
            lo, hi = max(0, target - GROQ_LARGE_SEARCH_WINDOW_MS), min(total, target + GROQ_LARGE_SEARCH_WINDOW_MS)
            candidates = [p for p in pauses if lo <= p <= hi]
            cut = min(candidates, key=lambda p: abs(p-target)) if candidates else target
        out.append((pos, cut))
        pos = cut
    return out


def build_colab_turbo_chunks(audio) -> list[tuple[int,int]]:
    pauses = detect_pause_centers(audio, COLAB_LANG_MIN_SILENCE_LEN, COLAB_LANG_SILENCE_THRESH_OFFSET)
    out, pos, total = [], 0, len(audio)
    while pos < total:
        eligible = [p for p in pauses if pos + COLAB_LANG_MIN_SEGMENT_MS <= p <= pos + COLAB_LANG_MAX_SEGMENT_MS]
        if eligible:
            cut = eligible[0]
        else:
            beyond = [p for p in pauses if pos + COLAB_LANG_MIN_SEGMENT_MS <= p <= pos + COLAB_LANG_MAX_SEGMENT_MS + COLAB_LANG_SEGMENT_SEARCH_MS]
            cut = beyond[0] if beyond else min(pos + COLAB_LANG_MAX_SEGMENT_MS, total)
        cut = min(cut, total)
        if cut <= pos:
            cut = min(pos + COLAB_LANG_MIN_SEGMENT_MS, total)
        out.append((pos, cut))
        pos = cut
    return out


def find_nearby_cut(audio, target_ms: int, window_ms: int, min_silence_len: int, offset_db: float) -> int:
    start, end = max(0, target_ms-window_ms), min(len(audio), target_ms+window_ms)
    window = audio[start:end]
    pauses = detect_pause_centers(window, min_silence_len, offset_db)
    if not pauses:
        return target_ms
    return start + min(pauses, key=lambda p: abs((start+p)-target_ms))


def enforce_groq_size_limit(audio, start_ms: int, end_ms: int, tmp_dir: Path) -> list[tuple[int,int]]:
    """Exact safety concept from the original Groq script:
    export FLAC, inspect actual bytes, recursively split if > 24 MiB."""
    test_path = tmp_dir / "size_check.flac"
    audio[start_ms:end_ms].export(test_path, format="flac")
    size = test_path.stat().st_size
    test_path.unlink(missing_ok=True)
    if size <= GROQ_MAX_CHUNK_BYTES or (end_ms - start_ms) < 60_000:
        return [(start_ms, end_ms)]
    midpoint = start_ms + (end_ms-start_ms)//2
    cut = find_nearby_cut(audio, midpoint, GROQ_SEARCH_WINDOW_MS,
                           GROQ_MIN_SILENCE_LEN, GROQ_SILENCE_THRESH_OFFSET)
    if cut <= start_ms or cut >= end_ms:
        cut = midpoint
    return enforce_groq_size_limit(audio, start_ms, cut, tmp_dir) + \
           enforce_groq_size_limit(audio, cut, end_ms, tmp_dir)


# ----------------------------
# DIARIZATION
# ----------------------------

def load_pyannote(token: str):
    from pyannote.audio import Pipeline
    return Pipeline.from_pretrained(PYANNOTE_MODEL, token=token)


def diarize_audio(audio_path: Path, hf_token: str, min_speakers=None, max_speakers=None) -> list[dict]:
    if not hf_token:
        raise ValueError("A Hugging Face token is required for pyannote Community-1.")
    print(f"[+] Loading pyannote model: {PYANNOTE_MODEL}")
    pipeline = load_pyannote(hf_token)
    kwargs = {}
    if min_speakers is not None:
        kwargs["min_speakers"] = min_speakers
    if max_speakers is not None:
        kwargs["max_speakers"] = max_speakers
    output = pipeline(str(audio_path), **kwargs)

    diar = getattr(output, "exclusive_speaker_diarization", None)
    if diar is None:
        diar = output.speaker_diarization

    turns = []
    for turn, speaker in diar:
        turns.append({
            "start": float(turn.start),
            "end": float(turn.end),
            "speaker": str(speaker),
        })
    turns.sort(key=lambda x: (x["start"], x["end"], x["speaker"]))
    return turns


def speakers_for_range(turns: list[dict], start_s: float, end_s: float) -> list[str]:
    weights = {}
    for t in turns:
        overlap = max(0.0, min(end_s, t["end"]) - max(start_s, t["start"]))
        if overlap > 0:
            weights[t["speaker"]] = weights.get(t["speaker"], 0.0) + overlap
    return [s for s, _ in sorted(weights.items(), key=lambda kv: kv[1], reverse=True)]


# ----------------------------
# SEGMENT MANIFEST
# ----------------------------

@dataclass
class Segment:
    segment_id: str
    source_index: int
    source_name: str
    combined_start_s: float
    combined_end_s: float
    duration_s: float
    speakers: list[str]
    primary_speaker: Optional[str]
    language: Optional[str] = None
    audio_path: Optional[str] = None
    transcript: Optional[str] = None
    status: str = "pending"


def locate_source(sources: list[dict], start_ms: int, end_ms: int) -> tuple[dict, float, float]:
    # A combined segment should not cross source boundaries when possible.
    # If it does, we still identify the source containing its start.
    for s in sources:
        if s["start_ms"] <= start_ms < s["end_ms"] or (start_ms == end_ms == s["end_ms"]):
            return s, max(0, start_ms-s["start_ms"])/1000, max(0, end_ms-s["start_ms"])/1000
    return sources[-1], 0, 0


def split_to_source_boundaries(chunks: list[tuple[int,int]], sources: list[dict]) -> list[tuple[int,int]]:
    boundaries = sorted(set([0] + [s["start_ms"] for s in sources] + [s["end_ms"] for s in sources]))
    out = []
    for a,b in chunks:
        cuts = [x for x in boundaries if a < x < b]
        prev = a
        for c in cuts:
            out.append((prev,c)); prev=c
        out.append((prev,b))
    return [(a,b) for a,b in out if b>a]


def build_manifest(combined_audio, sources, chunks, diar_turns, segments_dir: Path,
                   export_segments: bool) -> list[Segment]:
    segments = []
    for i,(a,b) in enumerate(chunks,1):
        if not (0 <= a < b <= len(combined_audio)):
            raise AssertionError(f"Invalid segment bounds: {a}, {b}, total={len(combined_audio)}")
        src, _, _ = locate_source(sources,a,b)
        spks = speakers_for_range(diar_turns, a/1000, b/1000)
        sid = f"seg_{i:06d}"
        out = segments_dir / f"{sid}.flac"
        if export_segments:
            combined_audio[a:b].export(out, format="flac")
        segments.append(Segment(
            segment_id=sid,
            source_index=src["index"],
            source_name=src["name"],
            combined_start_s=a/1000,
            combined_end_s=b/1000,
            duration_s=(b-a)/1000,
            speakers=spks,
            primary_speaker=spks[0] if spks else None,
            audio_path=str(out),
        ))
    return segments


def validate_manifest(segments: list[Segment], total_ms: int):
    last = 0.0
    for seg in segments:
        if seg.combined_start_s < 0 or seg.combined_end_s <= seg.combined_start_s:
            raise AssertionError(f"Bad segment {seg.segment_id}")
        if seg.combined_end_s*1000 > total_ms + 1:
            raise AssertionError(f"Segment exceeds combined audio: {seg.segment_id}")
        if seg.combined_start_s < last - 0.001:
            raise AssertionError(f"Manifest order regression at {seg.segment_id}")
        last = seg.combined_end_s


# ----------------------------
# GROQ STAGE 2
# ----------------------------

def load_groq_keys(keys_file: Path) -> list[dict]:
    if not keys_file.exists():
        return []
    try:
        return json.loads(keys_file.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_groq_keys(keys_file: Path, keys: list[dict]):
    atomic_json_write(keys_file, keys)


def select_groq_keys(keys_file: Path) -> list[str]:
    keys = load_groq_keys(keys_file)
    if not keys:
        label = ask("Label for new Groq key", "key1")
        key = ask("Paste Groq API key")
        keys = [{"label": label, "key": key}]
        save_groq_keys(keys_file, keys)
    while True:
        print("\nSaved Groq API keys:")
        for i,k in enumerate(keys,1):
            print(f"  {i}. {k.get('label','key'+str(i))}")
        print(f"  {len(keys)+1}. Add a new key")
        raw = ask("Select key(s), e.g. 1 or 1,3 or all")
        if raw.lower() == "all":
            return [k["key"] for k in keys]
        if raw == str(len(keys)+1):
            label = ask("Label for new key", f"key{len(keys)+1}")
            key = ask("Paste Groq API key")
            keys.append({"label":label,"key":key}); save_groq_keys(keys_file,keys)
            continue
        try:
            vals=[int(x.strip()) for x in raw.split(",") if x.strip()]
            selected=[keys[i-1]["key"] for i in vals if 1 <= i <= len(keys)]
            if selected: return selected
        except ValueError:
            pass
        print("[!] Invalid selection.")


def groq_error_is_rotation(e: Exception) -> bool:
    status = getattr(e, "status_code", None)
    msg = str(e).lower()
    return status in (429,401,403) or any(x in msg for x in ("rate limit","rate_limit","quota","too many requests"))


def groq_transcribe_segment(client, audio_path: Path, model_id: str, prompt: Optional[str], verbose: bool):
    with open(audio_path, "rb") as f:
        response = client.audio.transcriptions.create(
            file=(audio_path.name, f.read()),
            model=model_id,
            response_format="verbose_json" if verbose else "text",
            prompt=prompt,
        )
    if verbose:
        return response.text.strip(), getattr(response, "language", None)
    return str(response).strip(), None


def transcribe_groq(project: Path, combined_path: Path, segments: list[Segment],
                    model_choice: str, keys: list[str], translate_lang: Optional[str]):
    from groq import Groq
    from pydub import AudioSegment

    state_path = project / "groq_state.json"
    shared_path = unified_progress_path(project)
    state = {}
    if state_path.exists():
        try: state=json.loads(state_path.read_text(encoding="utf-8"))
        except Exception: state={}
    # If the unified ledger has newer Groq state, use it as the resume source.
    if shared_path.exists():
        try:
            shared=json.loads(shared_path.read_text(encoding="utf-8"))
            shared_groq=shared.get("backends",{}).get("groq",{})
            if shared_groq:
                state={**state, **shared_groq}
        except Exception:
            pass

    model_id = GROQ_MODEL_IDS[model_choice]
    redetect = model_choice == "turbo"
    key_index = int(state.get("key_index",0))
    key_index = min(key_index, len(keys)-1)
    client = Groq(api_key=keys[key_index])
    running_context = state.get("running_context","")
    last_lang = state.get("last_lang")
    audio = AudioSegment.from_file(combined_path).set_frame_rate(SAMPLE_RATE).set_channels(1)
    tmp = project / "tmp_groq"; tmp.mkdir(exist_ok=True)

    # Rebuild exact original-style chunking for Groq rather than assuming
    # Stage-1 segments are API-sized. This is the paranoia layer.
    raw = build_groq_turbo_chunks(audio) if redetect else build_groq_large_chunks(audio)
    api_chunks=[]
    for a,b in raw:
        api_chunks.extend(enforce_groq_size_limit(audio,a,b,tmp))
    print(f"[+] Groq safety chunking produced {len(api_chunks)} API chunk(s).")

    texts = state.get("texts", [None]*len(api_chunks))
    langs = state.get("langs", [None]*len(api_chunks))
    if len(texts)!=len(api_chunks): texts=[None]*len(api_chunks)
    if len(langs)!=len(api_chunks): langs=[None]*len(api_chunks)

    for i,(a,b) in enumerate(api_chunks):
        if texts[i] is not None:
            continue
        chunk_path=tmp/f"groq_{i:06d}.flac"
        audio[a:b].export(chunk_path,format="flac")
        actual=chunk_path.stat().st_size
        if actual > GROQ_MAX_CHUNK_BYTES:
            raise AssertionError(f"PARANOIA: Groq chunk still exceeds 24 MiB: {actual}")
        while True:
            print(f"[>] Groq {i+1}/{len(api_chunks)} {actual/1048576:.2f} MiB model={model_id} key={key_index+1}/{len(keys)}")
            try:
                text, lang = groq_transcribe_segment(
                    client, chunk_path, model_id,
                    running_context[-800:] if running_context else None,
                    redetect
                )
                if redetect and lang and last_lang and lang != last_lang:
                    print(f"[~] Language switch {last_lang} -> {lang}; dropping cross-language context.")
                    running_context=""
                if lang: last_lang=lang
                texts[i]=text; langs[i]=lang
                running_context=(running_context+" "+text).strip()
                atomic_json_write(state_path,{
                    "chunks":[[x,y] for x,y in api_chunks],
                    "texts":texts,"langs":langs,
                    "running_context":running_context,
                    "last_lang":last_lang,"key_index":key_index
                })
                update_unified_progress(project, "groq", **{k:v for k,v in state.items() if k in ("chunks","texts","langs","running_context","last_lang","key_index")})
                break
            except Exception as e:
                if groq_error_is_rotation(e):
                    print(f"[!] Groq key {key_index+1} quota/rate-limit: {e}")
                    time.sleep(GROQ_RATE_LIMIT_COOLDOWN_SEC)
                    key_index += 1
                    if key_index >= len(keys):
                        print("[STOPPED] All Groq keys exhausted; state saved.")
                        atomic_json_write(state_path,{
                            "chunks":[[x,y] for x,y in api_chunks],
                            "texts":texts,"langs":langs,
                            "running_context":running_context,
                            "last_lang":last_lang,"key_index":key_index
                        })
                        update_unified_progress(project, "groq", **{k:v for k,v in state.items() if k in ("chunks","texts","langs","running_context","last_lang","key_index")})
                        return
                    client=Groq(api_key=keys[key_index])
                    continue
                raise
        chunk_path.unlink(missing_ok=True)

    # Map API chunks back into the master segment transcript where possible.
    # This is intentionally conservative: each original Stage-1 segment gets
    # the API text whose center falls inside it.
    for seg in segments:
        pieces=[]
        for i,(a,b) in enumerate(api_chunks):
            center=(a+b)/2/1000
            if seg.combined_start_s <= center < seg.combined_end_s and texts[i]:
                pieces.append(texts[i])
        if pieces:
            seg.transcript=" ".join(pieces).strip()
            seg.status="done"
            if redetect:
                langs_here=[langs[i] for i,(a,b) in enumerate(api_chunks)
                            if seg.combined_start_s <= ((a+b)/2/1000) < seg.combined_end_s and langs[i]]
                if langs_here: seg.language=langs_here[0]


def transcribe_colab_mode(project: Path, combined_path: Path, segments: list[Segment], model_choice: str,
                          drive_save_dir: Optional[str] = None, translate_lang: Optional[str] = None):
    """Faster-whisper adapter. If executed in Colab, uses the same Drive/state
    layout as the original script. Outside Colab it uses project-local state."""
    try:
        import torch
        from faster_whisper import WhisperModel
    except ImportError as e:
        raise RuntimeError("Colab/local faster-whisper mode needs torch + faster-whisper.") from e

    in_colab = "google.colab" in sys.modules
    if in_colab:
        save_root=Path(drive_save_dir or "/content/drive/MyDrive/Transcripts")
        save_root.mkdir(parents=True,exist_ok=True)
        state_path=save_root/"batch_state.json"
    else:
        save_root=project/"colab_output"
        save_root.mkdir(exist_ok=True)
        state_path=save_root/"batch_state.json"

    try: state=json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {}
    except Exception: state={}
    shared_path = unified_progress_path(project)
    if shared_path.exists():
        try:
            shared=json.loads(shared_path.read_text(encoding="utf-8"))
            shared_colab=shared.get("backends",{}).get("colab",{})
            if shared_colab:
                state={**state, **shared_colab.get("state", {})}
        except Exception:
            pass

    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        gpu_name=torch.cuda.get_device_name(0)
        if model_choice=="turbo":
            if "T4" in gpu_name:
                model=WhisperModel("medium",device="cuda",compute_type="int8_float16")
            else:
                model=WhisperModel("large-v3-turbo",device="cuda",compute_type="int8_float16")
        else:
            model=WhisperModel("large-v3",device="cuda",compute_type="int8_float16" if "T4" in gpu_name else "float16")
    else:
        model=WhisperModel("small",device="cpu",compute_type="int8")

    from pydub import AudioSegment
    audio=AudioSegment.from_file(combined_path).set_frame_rate(SAMPLE_RATE).set_channels(1)

    # Keep the original Colab Turbo segmentation values.
    if model_choice=="turbo":
        chunks=build_colab_turbo_chunks(audio)
        print(f"[+] Colab Turbo segmentation: {len(chunks)} chunks, max ~25s.")
    else:
        chunks=[(0,len(audio))]

    for idx,(a,b) in enumerate(chunks):
        key=f"combined_{idx}_{a}_{b}"
        if state.get(key,{}).get("done"):
            continue
        tmp=project/"tmp_colab"; tmp.mkdir(exist_ok=True)
        p=tmp/f"colab_{idx:06d}.wav"
        audio[a:b].export(p,format="wav")
        if model_choice=="turbo":
            fw_segments,info=model.transcribe(str(p),beam_size=1,language=None,vad_filter=False)
        else:
            fw_segments,info=model.transcribe(str(p),beam_size=1)
        text_parts=[]
        for s in fw_segments:
            text_parts.append(s.text.strip())
        text=" ".join(x for x in text_parts if x).strip()
        for seg in segments:
            center=(a+b)/2/1000
            if seg.combined_start_s <= center < seg.combined_end_s:
                seg.transcript=(seg.transcript+" "+text).strip() if seg.transcript else text
                seg.status="done"
                seg.language=getattr(info,"language",None)
        state[key]={"done":True,"last_end":b/1000,"language":getattr(info,"language",None)}
        atomic_json_write(state_path,state)
        update_unified_progress(project, "colab", state=state, completed_chunks=sum(1 for v in state.values() if isinstance(v,dict) and v.get("done")))
        p.unlink(missing_ok=True)


# ----------------------------
# OUTPUT / FINAL COMPILER
# ----------------------------

def compile_outputs(project: Path, segments: list[Segment], diar_turns: list[dict]):
    validate_manifest(segments, int(max((s.combined_end_s for s in segments), default=0)*1000))
    manifest = {
        "app_version": APP_VERSION,
        "pyannote_model": PYANNOTE_MODEL,
        "segments": [asdict(s) for s in segments],
        "diarization_turns": diar_turns,
    }
    atomic_json_write(project/"segments_manifest.json",manifest)

    readable=project/"full_transcript.txt"
    with open(readable,"w",encoding="utf-8") as f:
        for seg in segments:
            if not seg.transcript:
                continue
            speaker=seg.primary_speaker or "UNKNOWN"
            lang=seg.language or "UNKNOWN"
            f.write(f"[{seg.combined_start_s:.2f}s -> {seg.combined_end_s:.2f}s] [SPEAKER={speaker}] [LANG={lang}]\n")
            f.write(seg.transcript.strip()+"\n\n")

    # Preserve a clean diarization file for downstream use.
    with open(project/"speaker_diarization.txt","w",encoding="utf-8") as f:
        for t in diar_turns:
            f.write(f"[{t['start']:.2f}s -> {t['end']:.2f}s] {t['speaker']}\n")

    print(f"[SUCCESS] {readable}")
    print(f"[SUCCESS] {project/'segments_manifest.json'}")


# ----------------------------
# PARANOIA CHECKS
# ----------------------------

def paranoia_check(project: Path, combined: Path, sources: list[dict], segments: list[Segment]):
    print("\n[PARANOIA] Running integrity checks...")
    if not combined.exists() or combined.stat().st_size == 0:
        raise AssertionError("Combined audio missing/empty.")
    if not sources:
        raise AssertionError("No sources recorded.")
    if not segments:
        raise AssertionError("No segments generated.")
    validate_manifest(segments, max(1, int(max(s.combined_end_s for s in segments)*1000)))

    # Check that segment files exist when exported.
    for s in segments:
        if s.audio_path and not Path(s.audio_path).exists():
            raise AssertionError(f"Missing segment audio: {s.audio_path}")

    # Check source ordering and durations.
    prev=0
    for s in sources:
        if s["start_ms"] != prev:
            raise AssertionError("Source timeline has a gap/overlap.")
        if s["end_ms"] <= s["start_ms"]:
            raise AssertionError("Invalid source duration.")
        prev=s["end_ms"]

    print("[PARANOIA] PASS: audio exists, source timeline is contiguous, segment bounds are valid, segment files exist.")


# ----------------------------
# INTERACTIVE RUNNER
# ----------------------------

def parse_args():
    p=argparse.ArgumentParser(description="Audio Pipeline Giant")
    p.add_argument("--project",default="audio_pipeline_project")
    p.add_argument("--input",nargs="*",default=[])
    p.add_argument("--url")
    p.add_argument("--mode",choices=["groq","colab"],default=None)
    p.add_argument("--model",choices=["turbo","large"],default=None)
    p.add_argument("--target-minutes",type=float,default=None,
                   help="Optional Stage-1 target chunk length. Stage-2 Groq/Colab retains its original chunk rules.")
    p.add_argument("--no-diarization",action="store_true")
    p.add_argument("--hf-token")
    p.add_argument("--min-speakers",type=int)
    p.add_argument("--max-speakers",type=int)
    p.add_argument("--translate")
    p.add_argument("--keep-segments",action="store_true")
    p.add_argument("--stage1-only",action="store_true")
    # Colab's kernel injects its own command-line flags. Ignore those so this
    # file can be pasted directly into a notebook cell.
    return p.parse_known_args()[0] if IN_COLAB else p.parse_args()


def main():
    args=parse_args()
    if IN_COLAB and args.project == "audio_pipeline_project":
        args.project = "/content/drive/MyDrive/AudioPipeline"
    project=Path(args.project).expanduser().resolve()
    if project.exists() and any(project.iterdir()):
        print(f"[!] Project already contains files: {project}")
        if not yes_no("Reuse this project and resume where possible?", True):
            raise SystemExit("Choose another --project directory.")

    project.mkdir(parents=True,exist_ok=True)
    segments_dir=project/"segments"; segments_dir.mkdir(exist_ok=True)
    if IN_COLAB:
        try:
            from google.colab import drive
            drive.mount("/content/drive", force_remount=False)
        except Exception as e:
            print(f"[!] Google Drive mount skipped: {e}")

    if args.mode:
        mode=args.mode.lower()
    else:
        # Explicitly ask this in Colab so the user can switch between Groq API
        # and the original local/Colab faster-whisper path.
        if IN_COLAB:
            use_groq=yes_no("Use Groq API for transcription? (No = use Colab/faster-whisper)", True)
            mode="groq" if use_groq else "colab"
        else:
            mode=ask("Stage-2 backend (groq/colab)", "groq").lower()
    model=args.model or ("turbo" if ask("Whisper model (turbo/large)", "turbo").lower()!="large" else "large")
    update_unified_progress(project, "groq" if mode=="groq" else "colab", stage="transcription", model=model, status="starting")

    if args.url:
        files=acquire_inputs(project,[],args.url)
    elif args.input:
        files=acquire_inputs(project,args.input,None)
    else:
        print("Enter local files/directories, comma-separated, OR leave blank and paste a URL next.")
        raw=input("Local paths: ").strip()
        if raw:
            files=acquire_inputs(project,[x.strip().strip('"') for x in raw.split(",")],None)
        else:
            url=input("URL: ").strip()
            files=acquire_inputs(project,[],url)

    print(f"[+] {len(files)} source audio file(s).")
    for i,p in enumerate(files,1):
        print(f"    {i}. {p}")

    combined=project/"combined_16k_mono.wav"
    sources,total_ms=splice_sources(files,combined)
    atomic_json_write(project/"sources_manifest.json",{"sources":sources,"total_duration_ms":total_ms})

    # Diarization.
    diar_turns=[]
    if not args.no_diarization:
        token=args.hf_token or os.environ.get("HF_TOKEN") or ask("Hugging Face token (used only for pyannote; leave blank to skip)")
        if token:
            diar_turns=diarize_audio(combined,token,args.min_speakers,args.max_speakers)
            atomic_json_write(project/"diarization.json",diar_turns)
            print(f"[+] Diarization: {len(diar_turns)} speaker turns.")
        else:
            print("[!] No HF token; speaker diarization skipped.")
    else:
        print("[+] Diarization disabled.")

    # Stage 1 segmentation.
    from pydub import AudioSegment
    audio=AudioSegment.from_file(combined)
    if args.target_minutes:
        target=max(0.1,args.target_minutes)*60_000
        raw_chunks=build_pause_chunks(audio,target,3_000,8_000,200,-16)
        print(f"[+] Stage-1 configurable target: ~{args.target_minutes:g} minute(s), snapped to pauses.")
    else:
        # Default Stage 1 uses the Groq Turbo-like pause behavior because that
        # was the user's favored "empty space detector" behavior.
        raw_chunks=build_groq_turbo_chunks(audio)
        print("[+] Stage-1 default: Groq-style short pause-aware chunks.")

    # Never allow a Stage-1 chunk to cross an original source boundary.
    raw_chunks=split_to_source_boundaries(raw_chunks,sources)

    segments=build_manifest(audio,sources,raw_chunks,diar_turns,segments_dir,True)
    validate_manifest(segments,total_ms)
    paranoia_check(project,combined,sources,segments)
    atomic_json_write(project/"segments_manifest.json",{
        "app_version":APP_VERSION,
        "stage1_target_minutes":args.target_minutes,
        "sources":sources,
        "segments":[asdict(s) for s in segments],
        "diarization_turns":diar_turns,
    })

    if args.stage1_only:
        print("[SUCCESS] Stage 1 complete. Existing transcriber can use the segment folder/manifest.")
        return

    if mode=="groq":
        key_file=project/"turbo_transcribe_keys.json"
        # If project has no key file, fall back to the old script's local filename.
        keys=select_groq_keys(key_file)
        translate=args.translate
        if translate is None:
            translate=ask("Translate final transcript to a language code, or blank to skip", "") or None
        transcribe_groq(project,combined,segments,model,keys,translate)
    else:
        translate=args.translate or None
        if translate is None and yes_no("Create a translated copy?",False):
            translate=ask("Target language code","es")
        transcribe_colab_mode(project,combined,segments,model,translate_lang=translate)

    paranoia_check(project,combined,sources,segments)
    compile_outputs(project,segments,diar_turns)

    # Do not delete sources or the project. Segment cleanup is optional.
    if not args.keep_segments:
        print("[+] Keeping segment files for downstream/debugging safety.")
    update_unified_progress(project, "groq" if mode=="groq" else "colab", stage="complete", model=model, status="done")
    print("\n[DONE] Pipeline completed.")
    print(f"[PROGRESS] Shared progress: {unified_progress_path(project)}")


if __name__=="__main__":
    main()
