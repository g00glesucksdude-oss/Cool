AUDIO PIPELINE GIANT
====================

This is the paranoid rebuild of the audio pipeline.

WHAT IT DOES
------------
1. Takes local audio files/directories OR a direct/Google Drive/MediaFire link.
2. Extracts ZIP batches automatically.
3. Normalizes each source to 16 kHz mono and splices them in deterministic order.
4. Runs pyannote Community-1 speaker diarization if you provide a Hugging Face token.
5. Creates pause-aware Stage-1 segments and records source/speaker metadata.
6. Sends the combined audio through either:
   - GROQ: preserves the important behavior from your Groq script.
   - COLAB/FASTER-WHISPER: preserves the important behavior from your Colab script.
7. Produces:
   - combined_16k_mono.wav
   - sources_manifest.json
   - diarization.json
   - speaker_diarization.txt
   - segments_manifest.json
   - full_transcript.txt
   - segments/*.flac

IMPORTANT DISTINCTION
---------------------
The configurable Stage-1 target length is NOT the Groq 24 MB limit.

Groq has TWO separate protections:
- its original Turbo/Large chunking rules
- the hard 24 MiB backend safety check

The Groq adapter deliberately rebuilds its own API chunks and FLAC-checks them.
If a chunk is over 24 MiB, it recursively splits it, preferably at silence.

The Colab adapter keeps the original:
- Turbo: ~25 second pause-aware language-redetection segments
- Large-v3: whole-file pass

STAGE 1 TARGET LENGTH
---------------------
Optional:
  --target-minutes 1
  --target-minutes 4
  --target-minutes 60

This affects Stage 1 segmentation only. It does NOT replace the original
Groq/Colab Stage-2 safety/chunking rules.

PYANNOTE
--------
The script uses:
  pyannote/speaker-diarization-community-1

You must accept the model conditions on Hugging Face and provide a token.
You can pass:
  --hf-token YOUR_TOKEN
or set HF_TOKEN.

Do not put your token in the source code.

INSTALL / GOOGLE COLAB
----------------------
The requirements are written INSIDE audio_pipeline.py.
If the file detects Google Colab, it automatically installs:
  pydub, groq, faster-whisper, pyannote.audio, deep-translator
and installs ffmpeg/unzip through apt.

So you can paste the ENTIRE audio_pipeline.py into a Colab cell and run it.
It ignores Colab's injected kernel command-line flags.
It mounts Google Drive and uses /content/drive/MyDrive/AudioPipeline as the
default project folder.

LOCAL PC
--------
Python 3.10/3.11 is recommended. Install the packages listed in REQUIREMENTS
at the top of the script and have ffmpeg available on PATH.

GROQ
----
Run:
  python audio_pipeline.py --mode groq

The script stores selected keys in:
  <project>/turbo_transcribe_keys.json

The Groq adapter retains:
- turbo/large model selection
- 45 sec Turbo maximum
- 3 sec Turbo minimum
- 8 sec Turbo search window
- 15 min Large target
- 30 sec Large search window
- 24 MiB FLAC safety ceiling
- key cycling
- 3 sec cooldown
- rate/quota detection
- running context
- language-switch context reset
- resumable JSON state

COLAB
-----
The Colab mode uses faster-whisper and detects whether it is actually running
inside Google Colab. In Colab it uses the Drive state location when available;
outside Colab it uses a local project state file.

The original Colab download helpers are also included in the unified script.

PARANOIA / SAFETY
-----------------
The program:
- never deletes your original source files
- refuses unsafe ZIP path traversal
- uses atomic JSON state writes
- validates segment bounds
- checks source timeline continuity
- checks generated segment files
- checks Groq FLAC size after export
- refuses to claim a chunk succeeded after an exception
- keeps project artifacts for inspection

IF SOMETHING FAILS
------------------
Do NOT delete the project directory immediately.

The useful forensic files are:
- sources_manifest.json
- diarization.json
- segments_manifest.json
- groq_state.json
- colab_output/batch_state.json

STAGE 1 ONLY
------------
To create the combined audio + diarization + segments without transcription:
  python audio_pipeline.py --stage1-only

Example:
  python audio_pipeline.py --input "D:\audio\pool" --target-minutes 4 --stage1-only

FULL GROQ EXAMPLE
-----------------
  python audio_pipeline.py --input "D:\audio\pool" --mode groq --model turbo --target-minutes 4

FULL COLAB/FASTER-WHISPER EXAMPLE
----------------------------------
  python audio_pipeline.py --input "D:\audio\pool" --mode colab --model turbo

NOTE
----
This is intentionally conservative rather than clever. If the output looks
wrong, the manifest and intermediate segment files should make it possible to
see exactly where the pipeline went wrong.
