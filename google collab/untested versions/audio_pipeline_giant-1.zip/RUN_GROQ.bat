@echo off
python audio_pipeline.py --mode groq --model turbo
pause
