AUDIO POOL COMPILER v2

This is the standalone compiler requested.

WORKFLOW
1. Choose a folder containing the audio pool.
2. Compile it into one normalized MASTER_AUDIO.wav.
3. Split the master into fixed 8-hour parts.
4. Select ONE OR MORE 8-hour parts.
5. Choose a target transcription chunk length in SECONDS:
     30    = 30 seconds
     60    = 1 minute
     240   = 4 minutes
     3600  = 1 hour
6. The program finds nearby silence boundaries and cuts there when possible.
   If no suitable silence is nearby, it falls back to the target time.
7. Transcribe the chunks externally, including with the cbro33 Whisper GUI.
8. Add one or more transcript-output folders.
9. Click MERGE. The program sorts the transcript files and creates one
   FULL_TRANSCRIPT.txt.

IMPORTANT
- 8-hour parts remain fixed at 8 hours.
- Transcription chunk size is configurable.
- Silence detection is approximate and intended to avoid cutting speech.
- ffmpeg and ffprobe must be installed and available on PATH.
- This tool does not control Groq, Colab, or the cbro33 GUI.
