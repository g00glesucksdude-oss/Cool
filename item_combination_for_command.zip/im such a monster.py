import uuid

# Supported slot locations
slot_map = {
    "mainhand": "slot.weapon.mainhand",
    "offhand": "slot.weapon.offhand",
    "hotbar": "slot.hotbar",          # requires slot=<index>
    "armor_head": "slot.armor.head",
    "armor_chest": "slot.armor.chest",
    "armor_legs": "slot.armor.legs",
    "armor_feet": "slot.armor.feet"
}

def tag_name(prefix: str) -> str:
    return f"{prefix}_{str(uuid.uuid4())[:8]}"

def build_selector(item, slot, data=None, quantity=None, hotbar_index=None):
    if slot == "slot.hotbar" and hotbar_index is not None:
        inner = f"hasitem={{item={item},location={slot},slot={hotbar_index}"
    else:
        inner = f"hasitem={{item={item},location={slot}"
    if data is not None:
        inner += f",data={data}"
    if quantity is not None:
        inner += f",quantity={quantity}"
    inner += "}"
    return f"@a[{inner}]"

def parse_input(user_input):
    parts = [p.strip() for p in user_input.split(",") if p.strip()]
    sequence, command, debug, scoreboard = [], None, False, "comboStep"
    for p in parts:
        up = p.upper()
        if up.startswith("COMMAND:"):
            command = p.split(":",1)[1].strip()
        elif up.startswith("DEBUG:"):
            debug = p.split(":",1)[1].strip().lower() == "true"
        elif up.startswith("SCOREBOARD:"):
            scoreboard = p.split(":",1)[1].strip()
        else:
            tokens = p.split()
            if len(tokens) < 2:
                raise ValueError(f"Invalid step: '{p}'")
            loc = tokens[0].lower()
            idx = None
            if loc == "hotbar":
                if len(tokens) < 3 or not tokens[1].isdigit():
                    raise ValueError("Hotbar requires numeric slot index before item (e.g., 'hotbar 3 minecraft:emerald')")
                idx = int(tokens[1])
                item = tokens[2]
                extra = tokens[3:]
            else:
                item = tokens[1]
                extra = tokens[2:]
            slot = slot_map.get(loc)
            if slot is None:
                raise ValueError(f"Unknown location '{loc}'")
            sequence.append((slot,item,idx,extra))
    return sequence, command, debug, scoreboard

def generate_chain(sequence, command, debug, scoreboard):
    commands = []
    # Setup scoreboard
    commands.append(f"scoreboard objectives add {scoreboard} dummy {scoreboard}")
    commands.append(f"scoreboard players add @a {scoreboard} 0")

    tags = []
    for idx,(slot,item,hotbar_index,extra) in enumerate(sequence, start=1):
        ishold = tag_name("ishold")
        hasheld = tag_name("hasheld")
        tags.append((ishold,hasheld))

        data, quantity = None, None
        for tok in extra:
            if tok.startswith("data="):
                data = int(tok.split("=")[1])
            elif tok.startswith("quantity="):
                quantity = int(tok.split("=")[1])

        sel_hold = build_selector(item,slot,data,quantity,hotbar_index)
        sel_not  = build_selector(item,slot,data,0,hotbar_index)

        # Holding state gated by scoreboard
        commands.append(f"tag {sel_hold} add {ishold}")
        commands.append(f"execute as @a[tag={ishold},scores={{{scoreboard}={idx-1}}}] run tag @s add {hasheld}")
        commands.append(f"execute as @a[tag={ishold},scores={{{scoreboard}={idx-1}}}] run scoreboard players set @s {scoreboard} {idx}")
        commands.append(f"tag {sel_not} remove {ishold}")

        if debug:
            commands.append(f"title @a[tag={ishold}] actionbar Step {idx} ({item})")

    # Final execute
    commands.append(f"execute as @a[scores={{{scoreboard}={len(sequence)}}}] run {command}")

    # Reset block
    for ishold,hasheld in tags[:-1]:
        commands.append(f"execute as @a[scores={{{scoreboard}={len(sequence)}}}] run tag @s remove {ishold}")
        commands.append(f"execute as @a[scores={{{scoreboard}={len(sequence)}}}] run tag @s remove {hasheld}")

    # Last step unconditional removal
    last_ishold, last_hasheld = tags[-1]
    commands.append(f"execute as @a[scores={{{scoreboard}={len(sequence)}}}] run tag @s remove {last_ishold}")
    commands.append(f"tag @a remove {last_hasheld}")

    # Reset scoreboard
    commands.append(f"scoreboard players set @a[scores={{{scoreboard}={len(sequence)}}}] {scoreboard} 0")
    return commands

if __name__=="__main__":
    print("Enter sequence like:")
    print("mainhand minecraft:diamond, hotbar 3 minecraft:emerald, armor_head minecraft:diamond_helmet, COMMAND: say Combo complete!, DEBUG: true, SCOREBOARD: comboStep")
    user_input=input("> ")
    seq,cmd,dbg,score=parse_input(user_input)
    chain=generate_chain(seq,cmd,dbg,score)
    print("\n# Auto-generated verbose Bedrock chain")
    for c in chain:
        print(c)
