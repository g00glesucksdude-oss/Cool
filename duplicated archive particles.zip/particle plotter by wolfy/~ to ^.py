import tkinter as tk
from tkinter import filedialog, messagebox
import re

def convert_mcfunction():
    file_path = filedialog.askopenfilename(
        title="Select a .mcfunction file",
        filetypes=[("MCFunction files", "*.mcfunction")]
    )
    if not file_path:
        return

    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    converted_lines = []
    for line in lines:
        original = line.strip()

        # Replace ~ with ^
        line = line.replace("~", "^")

        # Remove trailing minecraft:air
        line = re.sub(r"\s*minecraft:air\s*$", "", line)

        parts = line.strip().split()

        # Convert fill → fill ... destroy (no offsets)
        if original.startswith("fill "):
            # Keep the 6 coords as-is (after ~→^ and air removal)
            coords = parts[1:7]
            line = "fill " + " ".join(coords) + " destroy\n"

        # Convert setblock → fill (same start/end) destroy (no offsets)
        elif original.startswith("setblock "):
            coords = parts[1:4]
            line = "fill " + " ".join(coords) + " " + " ".join(coords) + " destroy\n"

        converted_lines.append(line)

    with open(file_path, "w", encoding="utf-8") as f:
        f.writelines(converted_lines)

    messagebox.showinfo("Done", "Conversion complete (no offsets).")

if __name__ == "__main__":
    convert_mcfunction()
