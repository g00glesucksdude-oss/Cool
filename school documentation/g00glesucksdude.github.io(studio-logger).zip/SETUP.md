# ADPCM Log Studio in the cloud: setup (one time, free, doable on a phone)

## How it works
1. **Web page** (`index.html` on github.io) looks like your desktop app. You select audio files, it reads their
   times, uploads them to **Google Drive (account A)** with those times kept, and starts an **ingest** job.
   Everything lives in one Drive folder that the app creates for you: **Logger workspace**
   (`uploads/` for jobs, `outputs/audio`, `outputs/video`, `index/` for the Audio tree, and `_index.json`, a combined copy of the tree for other programs).
2. The **ingest job** (GitHub Actions) merges the files like the desktop app, then saves a waveform file and a
   small playable copy back to Drive. A few minutes later the page shows the waveform.
3. In the page you zoom, play, set start/end points and build the segment queue.
4. **Export** starts a second cloud job. It renders `.ogg` or `.mp4` parts, uploads videos to **YouTube
   (account B, unlisted)**, then uploads to your **Drive output folder (public)**. You can close the page.
- GitHub is separate from both Google accounts. Drive and YouTube can be different accounts.

## 1. Repo and GitHub Pages
1. Make a **public** repo (free plans only serve Pages from public repos).
2. Add `index.html` and `cloud_pipeline.py` at the root, and the workflow at `.github/workflows/log-studio.yml`.
3. Settings → Pages → Deploy from branch → `main` / root. Your page: `https://<user>.github.io/<repo>/`.
4. Public repo means run logs are public. They show file names and the links. Secrets stay hidden.

## 2. Google Cloud project (free)
1. Enable **YouTube Data API v3** and **Google Drive API**.
2. OAuth consent screen: External. Add **both** Google accounts as test users. Scopes: `youtube.upload` and `drive`.
   Then **Publish app**, or tokens die after 7 days.
3. Create an OAuth client, type **Web application**:
   - Authorized JavaScript origin: `https://<user>.github.io`
   - Authorized redirect URI: `https://developers.google.com/oauthplayground`
4. Keep the client ID and secret. One client serves both accounts.

## 3. Two refresh tokens (OAuth Playground)
Open https://developers.google.com/oauthplayground → gear → "Use your own OAuth credentials".
- **Drive token, signed in as account A:** scope `https://www.googleapis.com/auth/drive` → Exchange code → copy refresh token.
- **YouTube token, signed in as account B:** scope `https://www.googleapis.com/auth/youtube.upload` → same steps.
  For a brand channel, choose it on the channel picker.

## 4. GitHub secrets
Settings → Secrets and variables → Actions
- Secrets: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REFRESH_TOKEN` (Drive, account A), `YT_REFRESH_TOKEN` (YouTube, account B)
- No variable is needed. The output folders are created inside **Logger workspace** automatically.

## 5. Token for the page
GitHub → Settings → Developer settings → Fine-grained tokens. Repository: only this repo. Permission: **Actions: Read and write**.

## 6. First open
Open the page. The gear (top right) opens Settings. Under Connections enter `owner/repo` (for example `YOURNAME/log-studio`),
branch `main`, your Google client ID and the GitHub token, then tap **Save connections** and **Done**.

## Using it
1. **Select files…** and pick the sort. Check the list. **Upload and analyse**, choose account A, and keep the screen on until the upload finishes.
2. Wait for "Master ready". If you closed the page, reopen it and use **Open earlier…**.
3. Edit like the desktop app, then use an Export button. Links appear in the run's Summary on GitHub and in the **Audio tree**.

## Gear menu (Settings)
Prefixes, custom video title, resolution, Vorbis quality, part lengths, video look and background image, plus the upload targets:
- Videos go to **YouTube (unlisted)** by default. Optionally also save a **public copy in Drive** (`outputs/video`).
- Audio goes to Drive `outputs/audio` with a public link.
- **Add the upload date and time** to titles and descriptions (YouTube title, Drive file name and description).
- Move the uploaded audio to the Drive trash after an export.
- **Visualizer frame rate**: Normal (25 fps) or Lite (12 fps, about 2x faster).

## Limit warnings and recommendations
Before each export the page predicts the cloud time and temporary disk it will need. Normal exports start straight away.
Only when an export is predicted to come close to a limit (about 75% of the 6 hour job cap, or 80% of the runner's disk) does a dialog appear. It offers, best first:
- **Lite visualizer** (12 fps instead of 25, about 2x faster). Offered when that alone is enough.
- **Split into parallel cloud jobs.** One job per part, each downloading and decoding only the source files its part needs. Each part gets its own 6 hours and its own disk.
- **Image / GIF only look**, when you have chosen a background image.
- **Also save a public Drive copy**, when a video export has more parts than YouTube's daily upload quota.
You can also pick "Export anyway" or "Cancel". The estimates are rough (render speeds were measured on a small test machine).

**Parallel exports and retry.** The Audio tree shows "Parallel export: 3 of 5 parts done". If a part was killed or failed, **Retry missing** re-runs only those parts.
The uploaded audio is not removed automatically after a parallel export. Delete the job from the Audio tree when all parts are done.

## Audio tree (bottom of the page)
Shows each job and the exports it produced, with Drive and YouTube links. Each job and export is a small file in `Logger workspace/index`, so jobs running in parallel never overwrite each other.
`Logger workspace/_index.json` is a combined copy for other programs; it is rebuilt after every run and whenever the page refreshes the tree. Buttons: **Open** a job, **Delete job**, **Delete** one export,
**Delete all audio exports / video exports**, and **Check Drive and clean up** (removes entries for things you deleted by hand in Drive).
Deleting moves files to the Drive trash and updates the tree. Empty the Drive trash to free space. A YouTube video must be deleted in YouTube Studio.

## Cleanup
The cloud job works in a temporary folder on GitHub's runner and deletes it at the end. Only the Drive files above are kept.

## Limits
- Browsers expose only last-modified time, not creation time. "Timestamp in name" and "File name" sorts are also offered.
- The waveform is built from 200 bins per second, so the 5 s zoom is a little coarser than the desktop app.
- Playback uses a small mono copy (about 11 MB per hour of audio). Logs longer than 20 hours are split into 1-hour pieces; the page loads only the current hour (and the next) so memory stays low even for multi-day recordings.
- Keyboard shortcuts (Space, C) only work with a keyboard. On a phone use the buttons.
- There is no Cancel for cloud jobs; cancel a run from GitHub's Actions page.
- Jobs from an older version of the page (folder "Log Studio uploads") are moved into Logger workspace as `uploads` the first time you use the new page.
- YouTube: API projects that haven't passed the audit get videos forced to private. Videos over 15 minutes need a verified channel. Parts stay under 11 h.
- GitHub jobs stop at 6 h. Use "Image / GIF only (fast)" for very long logs.

## If GitHub says "Not Found" (404)
It means GitHub can't see the repo, the token's access to it, or the workflow file. Check:
1. Repo is typed as `YOURNAME/log-studio` (no https, no spaces).
2. The file is at exactly `.github/workflows/log-studio.yml` on the `main` branch, and the repo's **Actions** tab lists "Log Studio".
3. The fine-grained token's repository access includes this repo, with **Actions: Read and write**.
